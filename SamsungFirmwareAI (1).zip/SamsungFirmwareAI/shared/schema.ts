import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model for admin authentication
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  isAdmin: boolean("is_admin").default(false).notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  isAdmin: true,
});

// Blog posts
export const blogPosts = pgTable("blog_posts", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  content: text("content").notNull(),
  excerpt: text("excerpt").notNull(),
  featuredImage: text("featured_image"),
  published: boolean("published").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertBlogPostSchema = createInsertSchema(blogPosts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Samsung device models
export const deviceModels = pgTable("device_models", {
  id: serial("id").primaryKey(),
  modelNumber: text("model_number").notNull().unique(),
  deviceName: text("device_name").notNull(),
  imageUrl: text("image_url"),
  releaseYear: integer("release_year"),
  latestFirmware: text("latest_firmware"),
  oneUIVersion: text("one_ui_version"),
});

export const insertDeviceModelSchema = createInsertSchema(deviceModels).omit({
  id: true,
});

// Regions/CSC codes
export const regions = pgTable("regions", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  continent: text("continent"),
});

export const insertRegionSchema = createInsertSchema(regions).omit({
  id: true,
});

// Firmware compatibility check history
export const compatibilityChecks = pgTable("compatibility_checks", {
  id: serial("id").primaryKey(),
  deviceModel: text("device_model").notNull(),
  region: text("region").notNull(),
  currentFirmware: text("current_firmware"),
  knoxImportant: boolean("knox_important").default(true),
  resultData: json("result_data").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertCompatibilityCheckSchema = createInsertSchema(compatibilityChecks).omit({
  id: true,
  createdAt: true,
});

// Site settings
export const siteSettings = pgTable("site_settings", {
  id: serial("id").primaryKey(),
  settingKey: text("setting_key").notNull().unique(),
  settingValue: text("setting_value"),
  category: text("category").notNull(),
  lastUpdated: timestamp("last_updated").defaultNow().notNull(),
});

export const insertSiteSettingSchema = createInsertSchema(siteSettings).omit({
  id: true,
  lastUpdated: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type BlogPost = typeof blogPosts.$inferSelect;
export type InsertBlogPost = z.infer<typeof insertBlogPostSchema>;

export type DeviceModel = typeof deviceModels.$inferSelect;
export type InsertDeviceModel = z.infer<typeof insertDeviceModelSchema>;

export type Region = typeof regions.$inferSelect;
export type InsertRegion = z.infer<typeof insertRegionSchema>;

export type CompatibilityCheck = typeof compatibilityChecks.$inferSelect;
export type InsertCompatibilityCheck = z.infer<typeof insertCompatibilityCheckSchema>;

export type SiteSetting = typeof siteSettings.$inferSelect;
export type InsertSiteSetting = z.infer<typeof insertSiteSettingSchema>;

// Firmware check result type
export interface FirmwareAnalysisResult {
  latestFirmware: {
    version: string;
    released: string;
    size: string;
  };
  compatibilityAnalysis: {
    bootloaderCompatible: boolean;
    bootloaderVersion: string;
    cscMatch: boolean;
    cscRegion: string;
    securityUpdate: boolean;
    securityPatchLevel: string;
  };
  safetyAssessment: {
    safeToFlash: boolean;
    knoxSafe: boolean;
    explanation: string;
  };
  recommendations: string[];
}
