import { FirmwareAnalysisResult } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export interface FirmwareCheckRequest {
  deviceModel: string;
  region: string;
  currentFirmware?: string;
  knoxImportant: boolean;
}

export const checkFirmwareCompatibility = async (
  data: FirmwareCheckRequest
): Promise<FirmwareAnalysisResult> => {
  try {
    const response = await apiRequest("POST", "/api/firmware-check", data);
    const result = await response.json();
    return result as FirmwareAnalysisResult;
  } catch (error) {
    console.error("Error checking firmware compatibility:", error);
    throw new Error("Failed to check firmware compatibility");
  }
};
