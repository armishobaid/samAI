// Animations for the website using Framer Motion
export const fadeIn = (delay?: number) => ({
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      delay: delay || 0,
      duration: 0.6,
    },
  },
});

export const fadeInUp = (delay?: number) => ({
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      delay: delay || 0,
      duration: 0.6,
    },
  },
});

export const fadeInDown = (delay?: number) => ({
  hidden: { opacity: 0, y: -20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      delay: delay || 0,
      duration: 0.6,
    },
  },
});

export const fadeInLeft = (delay?: number) => ({
  hidden: { opacity: 0, x: -20 },
  visible: {
    opacity: 1,
    x: 0,
    transition: {
      delay: delay || 0,
      duration: 0.6,
    },
  },
});

export const fadeInRight = (delay?: number) => ({
  hidden: { opacity: 0, x: 20 },
  visible: {
    opacity: 1,
    x: 0,
    transition: {
      delay: delay || 0,
      duration: 0.6,
    },
  },
});

export const staggerContainer = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.12,
    },
  },
};

export const scaleIn = (delay?: number) => ({
  hidden: { opacity: 0, scale: 0.9 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: {
      delay: delay || 0,
      duration: 0.5,
    },
  },
});

export const pulseAnimation = {
  initial: { scale: 1 },
  animate: {
    scale: [1, 1.03, 1],
    transition: {
      duration: 1.5,
      repeat: Infinity,
      repeatType: "loop" as const,
    },
  },
};

export const floatAnimation = {
  initial: { y: 0 },
  animate: {
    y: [0, -10, 0],
    transition: {
      duration: 3,
      repeat: Infinity,
      repeatType: "loop" as const,
      ease: "easeInOut",
    },
  },
};

export const shimmerAnimation = {
  initial: { backgroundPosition: "-500px 0" },
  animate: {
    backgroundPosition: ["500px 0", "-500px 0"],
    transition: {
      repeat: Infinity,
      repeatType: "mirror" as const,
      duration: 2,
      ease: "linear",
    },
  },
};