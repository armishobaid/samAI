import Hero from '@/components/home/Hero';
import Features from '@/components/home/Features';
import HowItWorks from '@/components/home/HowItWorks';
import PopularDevices from '@/components/home/PopularDevices';
import Testimonials from '@/components/home/Testimonials';
import FAQ from '@/components/home/FAQ';
import CTA from '@/components/home/CTA';
import RecentBlogPosts from '@/components/home/RecentBlogPosts';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import { Helmet } from 'react-helmet';
import FirmwareCheckerForm from '@/components/firmware/FirmwareCheckerForm';
import { useState } from 'react';
import { FirmwareFormValues } from '@/components/firmware/FirmwareCheckerForm';
import { FirmwareAnalysisResult } from '@shared/schema';
import FirmwareResults from '@/components/firmware/FirmwareResults';
import { useMutation, useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { FirmwareCheckRequest } from '@/lib/openai';

export default function Home() {
  const [firmwareResult, setFirmwareResult] = useState<FirmwareAnalysisResult | null>(null);
  const [submittedModel, setSubmittedModel] = useState<string>('');
  
  // Get device details when a model is selected
  const { data: deviceDetails } = useQuery<{ deviceName?: string }>({
    queryKey: ['/api/device-models', submittedModel],
    enabled: !!submittedModel
  });
  
  // Mutation for checking firmware compatibility
  const checkFirmwareMutation = useMutation({
    mutationFn: async (data: FirmwareCheckRequest) => {
      const response = await fetch('/api/firmware-check', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
      });
      
      if (!response.ok) {
        throw new Error('Failed to check firmware compatibility');
      }
      
      return response.json() as Promise<FirmwareAnalysisResult>;
    },
    onSuccess: (data) => {
      setFirmwareResult(data);
      
      // Scroll to results
      const resultsElement = document.getElementById('firmware-results');
      if (resultsElement) {
        resultsElement.scrollIntoView({ behavior: 'smooth' });
      }
    }
  });
  
  const handleFormSubmit = (values: FirmwareFormValues) => {
    setSubmittedModel(values.deviceModel);
    
    const requestData: FirmwareCheckRequest = {
      deviceModel: values.deviceModel,
      region: values.region,
      currentFirmware: values.currentFirmware || undefined,
      knoxImportant: values.knoxImportant === 'yes'
    };
    
    checkFirmwareMutation.mutate(requestData);
  };
  
  return (
    <>
      <Helmet>
        <title>SamFirms - Samsung Firmware Compatibility Checker</title>
        <meta 
          name="description" 
          content="Check Samsung firmware compatibility before flashing. Prevent bricking and warranty void with our AI-powered firmware analysis tool."
        />
      </Helmet>
      <Header />
      <main className="flex-grow">
        <Hero />
        
        {/* Firmware Checker Section with Ad Space */}
        <section className="py-16 bg-gradient-to-br from-gray-50 to-gray-100">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-5xl mx-auto">
              <div className="text-center mb-8">
                <h2 className="text-3xl font-bold mb-4">Check Your Firmware Compatibility</h2>
                <p className="text-muted-foreground max-w-2xl mx-auto">
                  Enter your Samsung device details below for AI-powered compatibility analysis
                </p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                {/* AdSense Ad Space - Left Sidebar */}
                <div className="hidden md:block md:col-span-1">
                  <div className="bg-gray-200 p-4 rounded-lg h-full flex items-center justify-center text-center">
                    <p className="text-gray-500 text-sm">Ad Space<br/>(300x600)</p>
                  </div>
                </div>
                
                {/* Firmware Checker Form */}
                <div className="md:col-span-3">
                  <div id="firmware-results">
                    {firmwareResult && (
                      <FirmwareResults 
                        deviceModel={submittedModel}
                        deviceName={deviceDetails?.deviceName}
                        result={firmwareResult} 
                      />
                    )}
                  </div>
                  
                  <FirmwareCheckerForm 
                    onSubmit={handleFormSubmit}
                    initialValues={{
                      deviceModel: '',
                      region: '',
                      currentFirmware: '',
                      knoxImportant: 'yes'
                    }}
                    isSubmitting={checkFirmwareMutation.isPending}
                  />
                </div>
              </div>
              
              {/* AdSense Ad Space - Horizontal Banner */}
              <div className="mt-12">
                <div className="bg-gray-200 p-4 rounded-lg w-full flex items-center justify-center text-center h-[90px]">
                  <p className="text-gray-500 text-sm">Ad Space (728x90)</p>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        <Features />
        <HowItWorks />
        <PopularDevices />
        <RecentBlogPosts />
        <Testimonials />
        <FAQ />
        <CTA />
      </main>
      <Footer />
    </>
  );
}
