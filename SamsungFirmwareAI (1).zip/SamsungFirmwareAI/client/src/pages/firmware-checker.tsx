import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { DeviceModel, FirmwareAnalysisResult } from '@shared/schema';
import { checkFirmwareCompatibility, FirmwareCheckRequest } from '@/lib/openai';
import { useToast } from '@/hooks/use-toast';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import FirmwareCheckerForm, { FirmwareFormValues } from '@/components/firmware/FirmwareCheckerForm';
import FirmwareResults from '@/components/firmware/FirmwareResults';
import { Helmet } from 'react-helmet';

export default function FirmwareCheckerPage() {
  const [location] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [searchParams, setSearchParams] = useState<URLSearchParams>();
  const [firmwareResult, setFirmwareResult] = useState<FirmwareAnalysisResult | null>(null);
  const [submittedModel, setSubmittedModel] = useState<string>('');

  // Parse URL parameters
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setSearchParams(params);
  }, [location]);

  // Get device model from URL if present
  const initialDeviceModel = searchParams?.get('model') || '';

  // Get device details if model is provided
  const { data: deviceDetails } = useQuery<DeviceModel>({
    queryKey: ['/api/device-models', initialDeviceModel],
    enabled: !!initialDeviceModel,
  });

  // Mutation for firmware check
  const checkFirmwareMutation = useMutation({
    mutationFn: checkFirmwareCompatibility,
    onSuccess: (data) => {
      setFirmwareResult(data);
      queryClient.invalidateQueries({ queryKey: ['/api/device-models'] });
      window.scrollTo({ top: 0, behavior: 'smooth' });
    },
    onError: (error) => {
      toast({
        title: "Error checking firmware compatibility",
        description: error.message || "An unknown error occurred",
        variant: "destructive"
      });
    }
  });

  const handleFormSubmit = (values: FirmwareFormValues) => {
    const requestData: FirmwareCheckRequest = {
      deviceModel: values.deviceModel,
      region: values.region,
      currentFirmware: values.currentFirmware || undefined,
      knoxImportant: values.knoxImportant === 'yes'
    };
    
    setSubmittedModel(values.deviceModel);
    checkFirmwareMutation.mutate(requestData);
  };

  return (
    <>
      <Helmet>
        <title>Firmware Compatibility Checker - FirmwareAI</title>
        <meta 
          name="description" 
          content="Check if your Samsung firmware is compatible with your device model and region. Prevent bricking and warranty issues with our AI-powered analysis."
        />
      </Helmet>
      <Header />
      <main className="flex-grow bg-gradient-to-b from-white to-gray-50">
        <section className="py-20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-5xl mx-auto">
              <div className="text-center mb-12">
                <h1 className="text-4xl md:text-5xl font-bold mb-6 relative inline-block">
                  <span className="relative z-10">Firmware Compatibility Checker</span>
                  <span className="absolute bottom-2 left-0 w-full h-3 bg-primary/10 -z-10 transform -rotate-1"></span>
                </h1>
                <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-6">
                  Enter your Samsung device details below to receive AI-powered compatibility analysis for firmware updates.
                </p>
                <div className="flex flex-wrap justify-center gap-3 text-sm text-muted-foreground">
                  <div className="flex items-center">
                    <div className="bg-green-500 w-3 h-3 rounded-full mr-2"></div>
                    <span>Bootloader Analysis</span>
                  </div>
                  <div className="flex items-center">
                    <div className="bg-blue-500 w-3 h-3 rounded-full mr-2"></div>
                    <span>CSC Verification</span>
                  </div>
                  <div className="flex items-center">
                    <div className="bg-amber-500 w-3 h-3 rounded-full mr-2"></div>
                    <span>Knox Status Check</span>
                  </div>
                  <div className="flex items-center">
                    <div className="bg-purple-500 w-3 h-3 rounded-full mr-2"></div>
                    <span>Security Analysis</span>
                  </div>
                </div>
              </div>
              
              {firmwareResult ? (
                <FirmwareResults 
                  deviceModel={submittedModel}
                  deviceName={deviceDetails?.deviceName}
                  result={firmwareResult} 
                />
              ) : null}
              
              <FirmwareCheckerForm 
                onSubmit={handleFormSubmit}
                initialValues={{
                  deviceModel: initialDeviceModel,
                  region: '',
                  currentFirmware: '',
                  knoxImportant: 'yes'
                }}
                isSubmitting={checkFirmwareMutation.isPending}
              />
              
              <div className="mt-16 bg-white rounded-2xl shadow-sm p-8 border border-gray-100">
                <h2 className="text-2xl font-bold mb-4">Why Use Our Firmware Checker?</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="flex">
                    <div className="flex-shrink-0 mr-4">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                        </svg>
                      </div>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-2">Prevent Bricking</h3>
                      <p className="text-muted-foreground">Our AI checks bootloader compatibility to ensure your device won't be bricked during the flashing process.</p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="flex-shrink-0 mr-4">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                        </svg>
                      </div>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-2">Preserve Warranty</h3>
                      <p className="text-muted-foreground">Know in advance if flashing will void your Knox warranty, allowing you to make an informed decision.</p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="flex-shrink-0 mr-4">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary" viewBox="0 0 20 20" fill="currentColor">
                          <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" />
                        </svg>
                      </div>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-2">Get Latest Features</h3>
                      <p className="text-muted-foreground">Safely upgrade to the latest firmware version to enjoy new features and improved performance.</p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="flex-shrink-0 mr-4">
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M18 8a6 6 0 01-7.743 5.743L10 14l-1 1-1 1H6v-1l1-1 1-1 .257-.257A6 6 0 1118 8zm-6-4a1 1 0 100 2 2 2 0 012 2 1 1 0 102 0 4 4 0 00-4-4z" clipRule="evenodd" />
                        </svg>
                      </div>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-2">AI-Powered Analysis</h3>
                      <p className="text-muted-foreground">Our advanced AI analyzes compatibility factors that manual checks might miss, providing greater reliability.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
