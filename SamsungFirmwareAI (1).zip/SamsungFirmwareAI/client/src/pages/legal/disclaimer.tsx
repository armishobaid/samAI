import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import { Helmet } from 'react-helmet';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertTriangle } from "lucide-react";
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';

export default function DisclaimerPage() {
  return (
    <>
      <Helmet>
        <title>Disclaimer - FirmwareAI</title>
        <meta 
          name="description" 
          content="Important disclaimer about using FirmwareAI Samsung firmware compatibility checker tool. Learn about the risks associated with firmware flashing."
        />
      </Helmet>
      <Header />
      <main className="flex-grow py-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl font-bold mb-6">Disclaimer</h1>
            
            <Alert variant="warning" className="mb-8">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Important Notice</AlertTitle>
              <AlertDescription>
                Flashing firmware can be risky. Always back up your data before proceeding and use our compatibility checker to minimize risks.
              </AlertDescription>
            </Alert>
            
            <div className="prose prose-lg max-w-none">
              <p className="text-muted-foreground">Last updated: June 1, 2023</p>
              
              <h2>General Disclaimer</h2>
              <p>
                The information provided on FirmwareAI is for general informational purposes only. All information on the site is provided in good faith, however, we make no representation or warranty of any kind, express or implied, regarding the accuracy, adequacy, validity, reliability, availability, or completeness of any information on the site.
              </p>
              
              <h2>Firmware Flashing Risks</h2>
              <p>
                Flashing firmware to your Samsung device involves inherent risks, including but not limited to:
              </p>
              <ul>
                <li>Voiding your device's warranty (Knox tripping)</li>
                <li>Permanently damaging ("bricking") your device</li>
                <li>Loss of data</li>
                <li>Security vulnerabilities</li>
                <li>Loss of functionality (like Samsung Pay, Secure Folder, etc.)</li>
                <li>Network connectivity issues</li>
              </ul>
              <p>
                Our AI-powered compatibility checker aims to minimize these risks by providing compatibility information, but it cannot eliminate them entirely.
              </p>
              
              <h2>No Affiliation with Samsung</h2>
              <p>
                FirmwareAI is not affiliated with, endorsed by, or in any way officially connected with Samsung Electronics Co., Ltd. Samsung, Galaxy, and all related names, logos, and products are trademarks of Samsung Electronics Co., Ltd. The use of these trademarks is for identification purposes only and does not imply any endorsement by or association with Samsung.
              </p>
              
              <h2>AI-Generated Content</h2>
              <p>
                Our firmware compatibility analysis is powered by artificial intelligence. While we strive for accuracy, AI-based systems have limitations and may occasionally provide incorrect information. Always cross-verify critical information before making decisions based on our compatibility checker.
              </p>
              
              <h2>No Liability</h2>
              <p>
                UNDER NO CIRCUMSTANCE SHALL WE HAVE ANY LIABILITY TO YOU FOR ANY LOSS OR DAMAGE OF ANY KIND INCURRED AS A RESULT OF THE USE OF OUR SERVICE OR RELIANCE ON ANY INFORMATION PROVIDED ON OUR WEBSITE. YOUR USE OF OUR SERVICE AND YOUR RELIANCE ON ANY INFORMATION ON OUR WEBSITE IS SOLELY AT YOUR OWN RISK.
              </p>
              
              <h2>External Links</h2>
              <p>
                Our website may contain links to external websites that are not provided or maintained by or in any way affiliated with us. We do not guarantee the accuracy, relevance, timeliness, or completeness of any information on these external websites.
              </p>
              
              <h2>Technical Information</h2>
              <p>
                The technical information regarding firmware compatibility, flashing methods, and device specifications is provided for educational purposes only. We do not encourage or support unauthorized modification of device software.
              </p>
              
              <h2>Acknowledgment</h2>
              <p>
                By using FirmwareAI, you acknowledge that you have read and understood this disclaimer, and you agree that you are using our Service at your own risk. If you do not agree with any part of this disclaimer, please do not use our Service.
              </p>
              
              <div className="mt-8 flex justify-center">
                <Link href="/firmware-checker">
                  <Button className="bg-primary hover:bg-primary/90 text-white">
                    I Understand the Risks - Continue to Firmware Checker
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
