import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import { Helmet } from 'react-helmet';

export default function PrivacyPage() {
  return (
    <>
      <Helmet>
        <title>Privacy Policy - FirmwareAI</title>
        <meta 
          name="description" 
          content="Privacy Policy for FirmwareAI - Learn how we collect, use, and protect your personal information when using our Samsung firmware compatibility checker."
        />
      </Helmet>
      <Header />
      <main className="flex-grow py-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl font-bold mb-6">Privacy Policy</h1>
            <div className="prose prose-lg max-w-none">
              <p className="text-muted-foreground">Last updated: June 1, 2023</p>
              
              <h2>1. Introduction</h2>
              <p>
                At FirmwareAI, we respect your privacy and are committed to protecting your personal data. This Privacy Policy explains how we collect, use, and safeguard your information when you use our website and services.
              </p>
              <p>
                Please read this Privacy Policy carefully to understand our practices regarding your personal data. By using our Service, you acknowledge that you have read and understood this Privacy Policy.
              </p>
              
              <h2>2. Information We Collect</h2>
              <p>
                We may collect the following types of information:
              </p>
              
              <h3>2.1 Information You Provide to Us</h3>
              <ul>
                <li>Device information (model number, current firmware version, region/CSC)</li>
                <li>Email address (if you subscribe to our newsletter)</li>
                <li>Any other information you choose to provide</li>
              </ul>
              
              <h3>2.2 Information We Collect Automatically</h3>
              <ul>
                <li>Usage information (such as how you use our Service)</li>
                <li>Device information (such as your IP address, browser type, and operating system)</li>
                <li>Cookies and similar tracking technologies</li>
              </ul>
              
              <h2>3. How We Use Your Information</h2>
              <p>
                We use the information we collect for various purposes, including:
              </p>
              <ul>
                <li>To provide and maintain our Service</li>
                <li>To process and complete firmware compatibility checks</li>
                <li>To improve and personalize our Service</li>
                <li>To communicate with you, including sending newsletters if you've subscribed</li>
                <li>To monitor usage of our Service</li>
                <li>To detect, prevent, and address technical issues</li>
              </ul>
              
              <h2>4. Cookies and Tracking Technologies</h2>
              <p>
                We use cookies and similar tracking technologies to track activity on our Service and hold certain information. Cookies are files with a small amount of data that may include an anonymous unique identifier.
              </p>
              <p>
                You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our Service.
              </p>
              
              <h2>5. Third-Party Services</h2>
              <p>
                Our Service may contain links to third-party websites or services that are not owned or controlled by us. We have no control over, and assume no responsibility for, the content, privacy policies, or practices of any third-party websites or services.
              </p>
              <p>
                We may use third-party service providers to:
              </p>
              <ul>
                <li>Facilitate our Service</li>
                <li>Provide the Service on our behalf</li>
                <li>Perform Service-related services</li>
                <li>Assist us in analyzing how our Service is used</li>
              </ul>
              <p>
                These third parties may have access to your personal data only to perform these tasks on our behalf and are obligated not to disclose or use it for any other purpose.
              </p>
              
              <h2>6. Data Retention</h2>
              <p>
                We will retain your personal data only for as long as is necessary for the purposes set out in this Privacy Policy. We will retain and use your personal data to the extent necessary to comply with our legal obligations, resolve disputes, and enforce our legal agreements and policies.
              </p>
              
              <h2>7. Data Security</h2>
              <p>
                The security of your data is important to us, but remember that no method of transmission over the Internet or method of electronic storage is 100% secure. While we strive to use commercially acceptable means to protect your personal data, we cannot guarantee its absolute security.
              </p>
              
              <h2>8. Your Data Protection Rights</h2>
              <p>
                Depending on your location, you may have certain rights regarding your personal data, such as:
              </p>
              <ul>
                <li>The right to access, update, or delete the information we have on you</li>
                <li>The right of rectification (to correct information)</li>
                <li>The right to object (to processing of your personal data)</li>
                <li>The right of restriction (to restrict processing of your data)</li>
                <li>The right to data portability</li>
                <li>The right to withdraw consent</li>
              </ul>
              
              <h2>9. Children's Privacy</h2>
              <p>
                Our Service does not address anyone under the age of 18. We do not knowingly collect personally identifiable information from anyone under the age of 18. If you are a parent or guardian and you are aware that your child has provided us with personal data, please contact us.
              </p>
              
              <h2>10. Changes to This Privacy Policy</h2>
              <p>
                We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page. You are advised to review this Privacy Policy periodically for any changes.
              </p>
              
              <h2>11. Contact Information</h2>
              <p>
                If you have any questions about this Privacy Policy, please contact us at:
              </p>
              <p>
                privacy@firmwareai.example.com
              </p>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
