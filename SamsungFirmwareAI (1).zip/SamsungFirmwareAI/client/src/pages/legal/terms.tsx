import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import { Helmet } from 'react-helmet';

export default function TermsPage() {
  return (
    <>
      <Helmet>
        <title>Terms of Service - FirmwareAI</title>
        <meta 
          name="description" 
          content="Terms of Service for FirmwareAI - Samsung Firmware Compatibility Checker tool. Read our legal terms and conditions of use."
        />
      </Helmet>
      <Header />
      <main className="flex-grow py-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-4xl font-bold mb-6">Terms of Service</h1>
            <div className="prose prose-lg max-w-none">
              <p className="text-muted-foreground">Last updated: June 1, 2023</p>
              
              <h2>1. Introduction</h2>
              <p>
                Welcome to FirmwareAI ("we," "our," or "us"). These Terms of Service ("Terms") govern your access to and use of the FirmwareAI website, including any content, functionality, and services offered on or through FirmwareAI (the "Service").
              </p>
              <p>
                Please read these Terms carefully before using our Service. By accessing or using our Service, you agree to be bound by these Terms. If you do not agree to these Terms, you must not access or use our Service.
              </p>
              
              <h2>2. Use of the Service</h2>
              <p>
                FirmwareAI provides an AI-powered Samsung firmware compatibility checking service. Our Service is intended solely to provide information and guidance regarding firmware compatibility. Any actions you take based on this information are at your own risk.
              </p>
              <p>
                You agree to use the Service only for lawful purposes and in accordance with these Terms. You agree not to:
              </p>
              <ul>
                <li>Use the Service in any way that violates any applicable federal, state, local, or international law or regulation</li>
                <li>Use the Service to distribute malware, viruses, or other malicious code</li>
                <li>Attempt to gain unauthorized access to, interfere with, damage, or disrupt any parts of the Service</li>
                <li>Use any robot, spider, or other automatic device to access or scrape the Service</li>
                <li>Use the Service for any commercial purpose without our prior written consent</li>
              </ul>
              
              <h2>3. Intellectual Property</h2>
              <p>
                The Service and its contents, features, and functionality are owned by us and are protected by copyright, trademark, and other intellectual property laws. You must not reproduce, distribute, modify, create derivative works of, publicly display, or exploit in any way any portion of the Service without our prior written consent.
              </p>
              
              <h2>4. Disclaimer of Warranties</h2>
              <p>
                THE SERVICE IS PROVIDED "AS IS" AND "AS AVAILABLE," WITHOUT ANY WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED. WE DISCLAIM ALL WARRANTIES, INCLUDING IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.
              </p>
              <p>
                We do not warrant that the Service will function without error or interruption, that defects will be corrected, or that the Service is free of viruses or other harmful components.
              </p>
              
              <h2>5. Limitation of Liability</h2>
              <p>
                TO THE FULLEST EXTENT PERMITTED BY LAW, IN NO EVENT WILL WE BE LIABLE FOR DAMAGES OF ANY KIND ARISING OUT OF OR IN CONNECTION WITH YOUR USE OF THE SERVICE, INCLUDING BUT NOT LIMITED TO DIRECT, INDIRECT, INCIDENTAL, PUNITIVE, AND CONSEQUENTIAL DAMAGES.
              </p>
              <p>
                WE SPECIFICALLY DISCLAIM ALL LIABILITY FOR ANY DAMAGE TO YOUR SAMSUNG DEVICE OR LOSS OF WARRANTY THAT MAY RESULT FROM USING OUR FIRMWARE COMPATIBILITY INFORMATION.
              </p>
              
              <h2>6. Indemnification</h2>
              <p>
                You agree to indemnify, defend, and hold harmless us and our officers, directors, employees, agents, and affiliates from any claims, liabilities, damages, and expenses (including reasonable attorneys' fees) arising out of or in any way connected with your use of the Service, your violation of these Terms, or your violation of any law or the rights of a third party.
              </p>
              
              <h2>7. Third-Party Links</h2>
              <p>
                The Service may contain links to third-party websites or services that are not owned or controlled by us. We have no control over, and assume no responsibility for, the content, privacy policies, or practices of any third-party websites or services. You further acknowledge and agree that we shall not be responsible or liable for any damage or loss caused by the use of such third-party websites or services.
              </p>
              
              <h2>8. Termination</h2>
              <p>
                We may terminate or suspend your access to the Service immediately, without prior notice or liability, for any reason, including if you breach these Terms. Upon termination, your right to use the Service will immediately cease.
              </p>
              
              <h2>9. Governing Law</h2>
              <p>
                These Terms shall be governed by and construed in accordance with the laws of the jurisdiction in which we are located, without regard to its conflict of law provisions.
              </p>
              
              <h2>10. Changes to Terms</h2>
              <p>
                We may revise these Terms at any time without notice. By continuing to access or use our Service after those revisions become effective, you agree to be bound by the revised Terms.
              </p>
              
              <h2>11. Contact Information</h2>
              <p>
                If you have any questions about these Terms, please contact us at:
              </p>
              <p>
                support@firmwareai.example.com
              </p>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
