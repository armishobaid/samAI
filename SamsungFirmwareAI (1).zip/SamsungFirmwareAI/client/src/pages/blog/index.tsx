import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { BlogPost } from '@shared/schema';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { Helmet } from 'react-helmet';

export default function BlogIndexPage() {
  const { data: posts, isLoading } = useQuery<BlogPost[]>({
    queryKey: ['/api/blog-posts']
  });

  // Format date for display
  const formatDate = (dateString: Date) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <>
      <Helmet>
        <title>Blog - Samsung Firmware Tips & Guides - FirmwareAI</title>
        <meta 
          name="description" 
          content="Read the latest articles about Samsung firmware updates, flashing guides, troubleshooting tips, and device optimization."
        />
      </Helmet>
      <Header />
      <main className="flex-grow py-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-5xl mx-auto">
            <h1 className="text-4xl font-bold mb-2">Blog</h1>
            <p className="text-muted-foreground text-lg mb-8">
              Latest articles about Samsung firmware updates, guides, and tips
            </p>

            {isLoading ? (
              // Loading state
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {[...Array(4)].map((_, index) => (
                  <Card key={index} className="overflow-hidden">
                    <Skeleton className="h-48 w-full" />
                    <CardHeader>
                      <Skeleton className="h-8 w-4/5 mb-2" />
                      <Skeleton className="h-4 w-1/3" />
                    </CardHeader>
                    <CardContent>
                      <Skeleton className="h-4 w-full mb-2" />
                      <Skeleton className="h-4 w-full mb-2" />
                      <Skeleton className="h-4 w-2/3" />
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : posts && posts.length > 0 ? (
              // Blog posts grid
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {posts.filter(post => post.published).map((post) => (
                  <Link key={post.id} href={`/blog/${post.slug}`}>
                    <Card className="overflow-hidden cursor-pointer hover:shadow-lg transition-shadow">
                      {post.featuredImage && (
                        <div 
                          className="h-48 w-full bg-center bg-cover" 
                          style={{ backgroundImage: `url(${post.featuredImage})` }}
                        />
                      )}
                      <CardHeader>
                        <CardTitle>{post.title}</CardTitle>
                        <CardDescription>{formatDate(post.createdAt)}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground">{post.excerpt}</p>
                      </CardContent>
                      <CardFooter>
                        <Button variant="link" className="p-0 text-primary">
                          Read More <i className="fas fa-arrow-right ml-1"></i>
                        </Button>
                      </CardFooter>
                    </Card>
                  </Link>
                ))}
              </div>
            ) : (
              // Empty state
              <div className="text-center py-16">
                <h3 className="text-2xl font-semibold mb-4">No Blog Posts Yet</h3>
                <p className="text-muted-foreground mb-8">
                  Check back soon for articles about Samsung firmware updates, flashing guides, and tips!
                </p>
              </div>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
