import { useQuery } from '@tanstack/react-query';
import { useParams, useLocation, Link } from 'wouter';
import { BlogPost } from '@shared/schema';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { Helmet } from 'react-helmet';

export default function BlogPostPage() {
  const { slug } = useParams();
  const [_, navigate] = useLocation();

  const { data: post, isLoading, isError } = useQuery<BlogPost>({
    queryKey: [`/api/blog-posts/${slug}`],
    enabled: !!slug,
    retry: false,
    onError: () => {
      // Redirect to blog index page if post not found
      navigate('/blog');
    }
  });

  // Format date for display
  const formatDate = (dateString: Date) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  if (isError) {
    return null; // Will redirect via onError
  }

  return (
    <>
      <Helmet>
        <title>{post ? `${post.title} - FirmwareAI Blog` : 'Loading Article - FirmwareAI Blog'}</title>
        <meta 
          name="description" 
          content={post?.excerpt || 'Loading article content...'}
        />
      </Helmet>
      <Header />
      <main className="flex-grow py-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto">
            <Link href="/blog">
              <Button variant="ghost" className="mb-6">
                <i className="fas fa-arrow-left mr-2"></i> Back to Blog
              </Button>
            </Link>

            {isLoading ? (
              // Loading state
              <div>
                <Skeleton className="h-12 w-3/4 mb-4" />
                <Skeleton className="h-6 w-48 mb-8" />
                <Skeleton className="h-64 w-full mb-8" />
                <div className="space-y-4">
                  <Skeleton className="h-5 w-full" />
                  <Skeleton className="h-5 w-full" />
                  <Skeleton className="h-5 w-full" />
                  <Skeleton className="h-5 w-3/4" />
                </div>
              </div>
            ) : post ? (
              <article>
                <h1 className="text-4xl font-bold mb-4">{post.title}</h1>
                <p className="text-muted-foreground mb-8">Published on {formatDate(post.createdAt)}</p>
                
                {post.featuredImage && (
                  <div className="mb-8">
                    <img 
                      src={post.featuredImage} 
                      alt={post.title} 
                      className="w-full h-auto rounded-lg"
                    />
                  </div>
                )}
                
                <div 
                  className="prose prose-lg max-w-none"
                  dangerouslySetInnerHTML={{ __html: post.content }}
                />
              </article>
            ) : null}
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
