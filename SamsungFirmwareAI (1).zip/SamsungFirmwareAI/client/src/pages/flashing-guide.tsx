import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { AlertTriangle } from "lucide-react";
import { Helmet } from 'react-helmet';

export default function FlashingGuidePage() {
  return (
    <>
      <Helmet>
        <title>Samsung Firmware Flashing Guide - FirmwareAI</title>
        <meta 
          name="description" 
          content="Complete guide to safely flash firmware on Samsung devices. Learn different flashing methods including Odin, Samsung Smart Switch, and Recovery Mode."
        />
      </Helmet>
      <Header />
      <main className="flex-grow py-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-5xl mx-auto">
            <h1 className="text-4xl font-bold mb-6">Samsung Firmware Flashing Guide</h1>
            <p className="text-muted-foreground text-lg mb-8">
              Learn how to safely flash firmware on your Samsung device using different methods.
              Always check firmware compatibility before flashing to prevent bricking your device.
            </p>

            <Alert variant="warning" className="mb-8">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Important Safety Warning</AlertTitle>
              <AlertDescription>
                Flashing firmware can potentially brick your device or void warranty if done incorrectly.
                Always back up your data before proceeding and ensure you have a compatible firmware version.
                Use our <a href="/firmware-checker" className="font-semibold underline">Firmware Compatibility Checker</a> first.
              </AlertDescription>
            </Alert>

            <Tabs defaultValue="odin" className="mb-12">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="odin">Odin Method</TabsTrigger>
                <TabsTrigger value="smartswitch">Smart Switch</TabsTrigger>
                <TabsTrigger value="recovery">Recovery Mode</TabsTrigger>
              </TabsList>
              
              <TabsContent value="odin" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Flashing with Odin (Windows)</CardTitle>
                    <CardDescription>
                      The most common method for flashing stock firmware on Samsung devices
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <h3 className="text-xl font-semibold">Requirements</h3>
                    <ul className="list-disc pl-5 space-y-2">
                      <li>Windows PC</li>
                      <li>Odin flashing tool (latest version, preferably 3.14.4 or newer)</li>
                      <li>USB cable (preferably the original cable)</li>
                      <li>Samsung USB drivers installed on your PC</li>
                      <li>Firmware files for your device (.tar or .md5 format)</li>
                      <li>Minimum 50% battery charge</li>
                    </ul>

                    <h3 className="text-xl font-semibold mt-6">Step-by-Step Instructions</h3>
                    <ol className="list-decimal pl-5 space-y-4">
                      <li>
                        <p className="font-medium">Download Required Files</p>
                        <p>Download the firmware files specific to your device model and region. These typically include BL, AP, CP, and CSC/HOME_CSC files.</p>
                      </li>
                      <li>
                        <p className="font-medium">Extract Firmware Files</p>
                        <p>Extract the downloaded firmware package to access the individual files needed for Odin.</p>
                      </li>
                      <li>
                        <p className="font-medium">Boot Device into Download Mode</p>
                        <p>Turn off your device completely. Press and hold Volume Down + Power + Bixby/Home button until you see the warning screen, then press Volume Up to enter Download Mode.</p>
                      </li>
                      <li>
                        <p className="font-medium">Open Odin on Your PC</p>
                        <p>Run Odin as Administrator. You should see a blue box indicating that Odin recognizes your device in Download Mode.</p>
                      </li>
                      <li>
                        <p className="font-medium">Load Firmware Files in Odin</p>
                        <ul className="list-disc pl-5 mt-2">
                          <li>Click BL and select the BL file (starts with BL_)</li>
                          <li>Click AP and select the AP file (starts with AP_)</li>
                          <li>Click CP and select the CP file (starts with CP_)</li>
                          <li>Click CSC and select the CSC file (starts with CSC_, not HOME_CSC unless you want to preserve data)</li>
                        </ul>
                      </li>
                      <li>
                        <p className="font-medium">Configure Odin Options</p>
                        <p>Make sure only "Auto Reboot" and "F. Reset Time" options are checked. Uncheck "Re-Partition" unless specifically instructed otherwise.</p>
                      </li>
                      <li>
                        <p className="font-medium">Start Flashing</p>
                        <p>Click the "Start" button in Odin and wait for the process to complete. Do not disconnect your device during this process.</p>
                      </li>
                      <li>
                        <p className="font-medium">Wait for "PASS!" Message</p>
                        <p>Once Odin shows a green "PASS!" message, your device will reboot automatically. The first boot may take several minutes as the system optimizes apps.</p>
                      </li>
                    </ol>
                    
                    <h3 className="text-xl font-semibold mt-6">Troubleshooting Common Issues</h3>
                    <div className="space-y-3">
                      <div>
                        <p className="font-medium">Odin Fails with "FAIL!" Message</p>
                        <p>Close Odin, reboot your PC, reinstall USB drivers, and try again with a different USB port.</p>
                      </div>
                      <div>
                        <p className="font-medium">Device Gets Stuck at Boot Logo</p>
                        <p>If your device is stuck in a boot loop, try booting into recovery mode (Volume Up + Power + Bixby/Home) and perform a factory reset.</p>
                      </div>
                      <div>
                        <p className="font-medium">Odin Doesn't Recognize Device</p>
                        <p>Try different USB cables, ports, or reinstall Samsung USB drivers. Make sure your device is properly in Download Mode.</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="smartswitch" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Flashing with Samsung Smart Switch</CardTitle>
                    <CardDescription>
                      Official Samsung tool for updating firmware with minimal risk
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <h3 className="text-xl font-semibold">Requirements</h3>
                    <ul className="list-disc pl-5 space-y-2">
                      <li>Windows PC or Mac</li>
                      <li>Samsung Smart Switch application installed</li>
                      <li>USB cable (preferably the original cable)</li>
                      <li>Internet connection (for downloading firmware)</li>
                      <li>Minimum 50% battery charge</li>
                    </ul>

                    <h3 className="text-xl font-semibold mt-6">Step-by-Step Instructions</h3>
                    <ol className="list-decimal pl-5 space-y-4">
                      <li>
                        <p className="font-medium">Download and Install Smart Switch</p>
                        <p>Download Samsung Smart Switch from Samsung's official website and install it on your computer.</p>
                      </li>
                      <li>
                        <p className="font-medium">Connect Your Device</p>
                        <p>Connect your Samsung device to your computer using a USB cable. Make sure USB debugging is enabled on your device.</p>
                      </li>
                      <li>
                        <p className="font-medium">Launch Smart Switch</p>
                        <p>Open Smart Switch. The program should recognize your device automatically.</p>
                      </li>
                      <li>
                        <p className="font-medium">Check for Updates</p>
                        <p>Click on the "Update" button in Smart Switch. The program will check if there's an available update for your device.</p>
                      </li>
                      <li>
                        <p className="font-medium">Download and Install Firmware</p>
                        <p>If an update is available, follow the on-screen instructions to download and install it. Do not disconnect your device during this process.</p>
                      </li>
                      <li>
                        <p className="font-medium">Complete the Update</p>
                        <p>After the update is installed, your device will restart automatically. The first boot may take several minutes.</p>
                      </li>
                    </ol>
                    
                    <h3 className="text-xl font-semibold mt-6">Advantages of Smart Switch</h3>
                    <ul className="list-disc pl-5 space-y-2">
                      <li>Official Samsung tool with minimal risk of bricking</li>
                      <li>User-friendly interface requiring no technical knowledge</li>
                      <li>Preserves user data during update (though backup is still recommended)</li>
                      <li>Available for both Windows and Mac</li>
                    </ul>
                    
                    <h3 className="text-xl font-semibold mt-6">Limitations</h3>
                    <ul className="list-disc pl-5 space-y-2">
                      <li>Can only update to the latest firmware for your region</li>
                      <li>Cannot downgrade firmware</li>
                      <li>Not all devices or firmware versions are supported</li>
                    </ul>
                  </CardContent>
                </Card>
              </TabsContent>
              
              <TabsContent value="recovery" className="mt-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Flashing from Recovery Mode</CardTitle>
                    <CardDescription>
                      Using ADB sideload to flash official firmware packages
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <h3 className="text-xl font-semibold">Requirements</h3>
                    <ul className="list-disc pl-5 space-y-2">
                      <li>Windows, Mac, or Linux computer</li>
                      <li>ADB and Fastboot tools installed</li>
                      <li>USB cable</li>
                      <li>Official OTA firmware package (.zip format)</li>
                      <li>Minimum 50% battery charge</li>
                    </ul>

                    <h3 className="text-xl font-semibold mt-6">Step-by-Step Instructions</h3>
                    <ol className="list-decimal pl-5 space-y-4">
                      <li>
                        <p className="font-medium">Download Required Files</p>
                        <p>Download the official OTA update package (.zip file) for your device model and region.</p>
                      </li>
                      <li>
                        <p className="font-medium">Install ADB Tools</p>
                        <p>Install ADB and Fastboot tools on your computer if you haven't already.</p>
                      </li>
                      <li>
                        <p className="font-medium">Boot Device into Recovery Mode</p>
                        <p>Turn off your device completely. Press and hold Volume Up + Power + Bixby/Home button until you see the Recovery Mode screen.</p>
                      </li>
                      <li>
                        <p className="font-medium">Select "Apply Update from ADB"</p>
                        <p>Use the volume buttons to navigate and the power button to select "Apply Update from ADB" option.</p>
                      </li>
                      <li>
                        <p className="font-medium">Connect Device to Computer</p>
                        <p>Connect your device to your computer using a USB cable.</p>
                      </li>
                      <li>
                        <p className="font-medium">Open Command Prompt/Terminal</p>
                        <p>Open Command Prompt (Windows) or Terminal (Mac/Linux) and navigate to the directory containing the ADB tools.</p>
                      </li>
                      <li>
                        <p className="font-medium">Verify ADB Connection</p>
                        <p>Type "adb devices" and press Enter to verify that your device is connected and recognized in sideload mode.</p>
                      </li>
                      <li>
                        <p className="font-medium">Sideload the Firmware</p>
                        <p>Type "adb sideload [path-to-zip-file]" and press Enter to start the sideload process.</p>
                      </li>
                      <li>
                        <p className="font-medium">Wait for Installation to Complete</p>
                        <p>Wait for the installation to complete. Do not disconnect your device during this process.</p>
                      </li>
                      <li>
                        <p className="font-medium">Reboot Device</p>
                        <p>After installation, select "Reboot system now" to restart your device with the new firmware.</p>
                      </li>
                    </ol>
                    
                    <h3 className="text-xl font-semibold mt-6">Advantages of Recovery Mode Flashing</h3>
                    <ul className="list-disc pl-5 space-y-2">
                      <li>Works on all operating systems with ADB support</li>
                      <li>Official update method supported by Samsung</li>
                      <li>Less risky than Odin method for beginners</li>
                      <li>Can be used to install official OTA updates</li>
                    </ul>
                    
                    <h3 className="text-xl font-semibold mt-6">Limitations</h3>
                    <ul className="list-disc pl-5 space-y-2">
                      <li>Only works with official OTA packages</li>
                      <li>Cannot be used for major OS upgrades in most cases</li>
                      <li>May not work on all Samsung models</li>
                    </ul>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>

            <div className="bg-white p-6 rounded-xl shadow-lg mt-8">
              <h2 className="text-2xl font-bold mb-4">Before You Flash: Essential Preparations</h2>
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold">1. Backup Your Data</h3>
                  <p className="text-muted-foreground">
                    Always back up all important data before flashing firmware. Use Samsung Cloud, Smart Switch, or Google account sync to ensure your contacts, photos, and other data are safe.
                  </p>
                </div>
                <div>
                  <h3 className="text-lg font-semibold">2. Verify Compatibility</h3>
                  <p className="text-muted-foreground">
                    Use our <a href="/firmware-checker" className="text-primary hover:underline">Firmware Compatibility Checker</a> to ensure the firmware you're planning to flash is compatible with your device model and region.
                  </p>
                </div>
                <div>
                  <h3 className="text-lg font-semibold">3. Charge Your Device</h3>
                  <p className="text-muted-foreground">
                    Ensure your device has at least 50% battery charge before starting the flashing process to prevent interruption due to power loss.
                  </p>
                </div>
                <div>
                  <h3 className="text-lg font-semibold">4. Download from Trusted Sources</h3>
                  <p className="text-muted-foreground">
                    Only download firmware files from official Samsung sources or reputable firmware databases to avoid corrupted or modified firmware.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
