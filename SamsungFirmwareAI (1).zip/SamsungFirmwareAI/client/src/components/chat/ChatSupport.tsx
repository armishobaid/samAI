import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle, X, Send, MessageSquare, Loader2 } from 'lucide-react';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'assistant';
  timestamp: Date;
}

export function ChatSupport() {
  const [isOpen, setIsOpen] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'Hello! I\'m your Samsung firmware assistant. How can I help you today?',
      sender: 'assistant',
      timestamp: new Date()
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom of messages
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!inputValue.trim()) return;
    
    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue,
      sender: 'user',
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);
    
    try {
      // In a real implementation, this would call an API endpoint
      // For now, we'll use a timeout to simulate the API call
      setTimeout(() => {
        const assistantMessage: Message = {
          id: (Date.now() + 1).toString(),
          text: getAssistantResponse(inputValue),
          sender: 'assistant',
          timestamp: new Date()
        };
        
        setMessages(prev => [...prev, assistantMessage]);
        setIsLoading(false);
      }, 1000);
    } catch (error) {
      console.error('Error sending message:', error);
      setIsLoading(false);
    }
  };

  // Simple response generation based on keywords
  const getAssistantResponse = (input: string): string => {
    const lowerInput = input.toLowerCase();
    
    if (lowerInput.includes('knox') || lowerInput.includes('warranty')) {
      return 'Knox is Samsung\'s security platform. When you flash unofficial firmware, the Knox warranty bit may be tripped, which voids your warranty. Our firmware checker helps you determine whether flashing will affect Knox status.';
    } 
    else if (lowerInput.includes('csc') || lowerInput.includes('region')) {
      return 'CSC (Country Specific Code) defines region-specific features on your Samsung device. When flashing firmware, it\'s important to use a compatible CSC to ensure proper functionality. You can either select from our list or enter a custom CSC code.';
    }
    else if (lowerInput.includes('odin')) {
      return 'Odin is Samsung\'s official firmware flashing tool. We recommend using Odin 3.14.4 or newer. Make sure to follow our flashing guide for step-by-step instructions to safely flash firmware.';
    }
    else if (lowerInput.includes('bootloader')) {
      return 'The bootloader version is critical for firmware compatibility. Downgrading to an incompatible bootloader can brick your device. Our firmware checker verifies bootloader compatibility before you flash.';
    }
    else if (lowerInput.includes('brick') || lowerInput.includes('bricked')) {
      return 'A "bricked" device won\'t boot properly due to firmware issues. This often happens when flashing incompatible firmware. Our tool helps prevent bricking by analyzing compatibility factors before you flash.';
    }
    else {
      return 'I can help with questions about Samsung firmware, CSC codes, Knox warranty, flashing procedures, and more. If you\'re unsure about flashing firmware, try our compatibility checker tool for your specific device model.';
    }
  };

  return (
    <>
      {/* Chat Button */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1 }}
        className="fixed bottom-4 right-4 z-50"
      >
        <Button
          onClick={() => setIsOpen(!isOpen)}
          className="h-14 w-14 rounded-full shadow-lg bg-primary hover:bg-primary/90"
        >
          {isOpen ? <X className="h-6 w-6" /> : <MessageSquare className="h-6 w-6" />}
        </Button>
      </motion.div>

      {/* Chat Window */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            transition={{ duration: 0.2 }}
            className="fixed bottom-[4.5rem] right-4 w-[350px] sm:w-[400px] z-50"
          >
            <Card className="overflow-hidden shadow-xl border-gray-200 rounded-2xl">
              {/* Chat Header */}
              <div className="bg-primary text-white p-4 flex justify-between items-center">
                <div className="flex items-center space-x-2">
                  <div className="h-8 w-8 bg-white/20 rounded-full flex items-center justify-center">
                    <MessageSquare className="h-4 w-4" />
                  </div>
                  <div>
                    <h3 className="font-semibold">SamFirms Assistant</h3>
                    <p className="text-xs text-white/80">Firmware support</p>
                  </div>
                </div>
                <Button 
                  size="sm" 
                  variant="ghost" 
                  onClick={() => setIsOpen(false)}
                  className="text-white hover:bg-white/20 hover:text-white h-8 w-8 p-0"
                >
                  <X className="h-5 w-5" />
                </Button>
              </div>

              {/* Messages Container */}
              <div className="p-4 h-[380px] overflow-y-auto bg-gray-50">
                <div className="space-y-4">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[85%] rounded-2xl p-3 ${
                          message.sender === 'user'
                            ? 'bg-primary text-white rounded-tr-none'
                            : 'bg-white shadow-sm border border-gray-100 rounded-tl-none'
                        }`}
                      >
                        <p className="text-sm">{message.text}</p>
                        <p 
                          className={`text-[10px] mt-1 text-right ${
                            message.sender === 'user' ? 'text-primary-foreground/80' : 'text-gray-400'
                          }`}
                        >
                          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          {message.sender === 'assistant' && (
                            <CheckCircle className="inline ml-1 h-3 w-3" />
                          )}
                        </p>
                      </div>
                    </div>
                  ))}
                  {isLoading && (
                    <div className="flex justify-start">
                      <div className="bg-white shadow-sm border border-gray-100 rounded-2xl rounded-tl-none p-3 max-w-[85%]">
                        <div className="flex items-center space-x-2">
                          <Loader2 className="h-4 w-4 animate-spin text-primary" />
                          <p className="text-sm text-gray-500">Typing...</p>
                        </div>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>
              </div>

              {/* Input Form */}
              <form onSubmit={handleSubmit} className="p-3 bg-white border-t">
                <div className="flex space-x-2">
                  <Input
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    placeholder="Type your message..."
                    className="flex-1"
                    disabled={isLoading}
                  />
                  <Button 
                    type="submit" 
                    size="icon"
                    disabled={isLoading || !inputValue.trim()}
                    className="bg-primary hover:bg-primary/90"
                  >
                    {isLoading ? (
                      <Loader2 className="h-5 w-5 animate-spin" />
                    ) : (
                      <Send className="h-5 w-5" />
                    )}
                  </Button>
                </div>
              </form>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}