import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Region } from '@shared/schema';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  Popover, 
  PopoverContent, 
  PopoverTrigger 
} from '@/components/ui/popover';
import { 
  Command, 
  CommandEmpty, 
  CommandGroup, 
  CommandInput, 
  CommandItem, 
  CommandList 
} from '@/components/ui/command';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Skeleton } from '@/components/ui/skeleton';
import { PhoneImage } from '@/components/ui/phone-image';
import { fadeIn, fadeInUp, staggerContainer } from '@/lib/animations';
import { Check, ChevronsUpDown, Plus } from 'lucide-react';
import { cn } from '@/lib/utils';

// Define the form schema
const formSchema = z.object({
  deviceModel: z.string().min(1, { message: "Device model is required" }),
  region: z.string().min(1, { message: "Region/CSC is required" }),
  customCSC: z.string().optional(),
  currentFirmware: z.string().optional(),
  knoxImportant: z.enum(["yes", "no"]),
});

export type FirmwareFormValues = z.infer<typeof formSchema>;

interface FirmwareCheckerFormProps {
  onSubmit: (values: FirmwareFormValues) => void;
  initialValues?: Partial<FirmwareFormValues>;
  isSubmitting?: boolean;
}

export default function FirmwareCheckerForm({ 
  onSubmit, 
  initialValues,
  isSubmitting = false
}: FirmwareCheckerFormProps) {
  const [showCustomCSC, setShowCustomCSC] = useState(false);
  const [openCSCCombobox, setOpenCSCCombobox] = useState(false);
  const [cscSearchValue, setCSCSearchValue] = useState('');
  
  // Fetch regions for dropdown
  const { data: regions = [], isLoading: isLoadingRegions } = useQuery<Region[]>({
    queryKey: ['/api/regions']
  });

  // Filtered regions based on search
  const filteredRegions = cscSearchValue 
    ? regions.filter(region => 
        region.name.toLowerCase().includes(cscSearchValue.toLowerCase()) || 
        region.code.toLowerCase().includes(cscSearchValue.toLowerCase())
      )
    : regions;

  // Set up form with react-hook-form
  const form = useForm<FirmwareFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      deviceModel: initialValues?.deviceModel || '',
      region: initialValues?.region || '',
      customCSC: '',
      currentFirmware: initialValues?.currentFirmware || '',
      knoxImportant: initialValues?.knoxImportant || 'yes',
    },
  });
  
  // When customCSC changes, update the region value
  useEffect(() => {
    const customCSC = form.watch('customCSC');
    if (showCustomCSC && customCSC) {
      form.setValue('region', customCSC);
    }
  }, [form.watch('customCSC'), showCustomCSC]);
  
  // When region is selected from dropdown, clear customCSC
  useEffect(() => {
    if (!showCustomCSC) {
      form.setValue('customCSC', '');
    }
  }, [showCustomCSC]);

  const handleSubmit = (values: FirmwareFormValues) => {
    // Use either selected region or custom CSC
    const finalValues = {
      ...values,
      region: showCustomCSC && values.customCSC ? values.customCSC : values.region || ''
    };
    onSubmit(finalValues);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
      <motion.div 
        className="md:col-span-2"
        initial="hidden"
        animate="visible"
        variants={fadeIn()}
      >
        <Card className="bg-white p-8 rounded-2xl shadow-xl border-0">
          <motion.div 
            className="mb-6"
            variants={fadeInUp(0.1)}
          >
            <h3 className="text-xl font-bold mb-2">Enter Your Device Details</h3>
            <p className="text-muted-foreground">
              Provide accurate information for the most precise compatibility check
            </p>
          </motion.div>
          
          <Form {...form}>
            <motion.form 
              onSubmit={form.handleSubmit(handleSubmit)} 
              className="space-y-6"
              variants={staggerContainer}
            >
              {/* Device Model */}
              <motion.div variants={fadeInUp(0.2)}>
                <FormField
                  control={form.control}
                  name="deviceModel"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-base font-medium">
                        Device Model <span className="text-red-500">*</span>
                      </FormLabel>
                      <FormControl>
                        <div className="relative">
                          <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-muted-foreground">
                            <i className="fas fa-mobile-alt"></i>
                          </span>
                          <Input 
                            placeholder="e.g., SM-G991B, SM-A546E" 
                            className="pl-10 py-6 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary"
                            {...field} 
                          />
                        </div>
                      </FormControl>
                      <FormDescription className="text-sm">
                        Enter your Samsung model number (e.g., SM-G991B)
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </motion.div>
              
              {/* Region/CSC */}
              <motion.div variants={fadeInUp(0.3)}>
                <div className="flex items-center justify-between mb-2">
                  <FormLabel className="text-base font-medium">
                    Region/CSC <span className="text-red-500">*</span>
                  </FormLabel>
                  <div className="flex items-center space-x-1">
                    <Button 
                      type="button" 
                      variant={showCustomCSC ? "outline" : "default"} 
                      size="sm"
                      className={`text-xs px-2 py-1 h-7 ${!showCustomCSC ? 'bg-primary text-white' : ''}`}
                      onClick={() => setShowCustomCSC(false)}
                    >
                      Select CSC
                    </Button>
                    <Button 
                      type="button" 
                      variant={showCustomCSC ? "default" : "outline"} 
                      size="sm"
                      className={`text-xs px-2 py-1 h-7 ${showCustomCSC ? 'bg-primary text-white' : ''}`}
                      onClick={() => setShowCustomCSC(true)}
                    >
                      Enter Custom
                    </Button>
                  </div>
                </div>
                
                {showCustomCSC ? (
                  // Custom CSC Entry
                  <FormField
                    control={form.control}
                    name="customCSC"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <div className="relative">
                            <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-muted-foreground">
                              <i className="fas fa-pen"></i>
                            </span>
                            <Input 
                              placeholder="Enter custom CSC code (e.g., BTU, XEF)" 
                              className="pl-10 py-6 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary"
                              {...field} 
                            />
                          </div>
                        </FormControl>
                        <FormDescription className="text-sm">
                          Enter a custom CSC code if your region is not listed
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                ) : (
                  // Searchable CSC Dropdown
                  <FormField
                    control={form.control}
                    name="region"
                    render={({ field }) => (
                      <FormItem className="flex flex-col">
                        <Popover open={openCSCCombobox} onOpenChange={setOpenCSCCombobox}>
                          <PopoverTrigger asChild>
                            <FormControl>
                              <div className="relative">
                                <Button
                                  variant="outline"
                                  role="combobox"
                                  aria-expanded={openCSCCombobox}
                                  className="w-full justify-between pl-10 py-6 border-gray-200 bg-white hover:bg-gray-50 text-left font-normal"
                                >
                                  <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-muted-foreground z-10">
                                    <i className="fas fa-globe-americas"></i>
                                  </span>
                                  {field.value ? (
                                    regions.find(region => region.code === field.value)?.name ?
                                    `${regions.find(region => region.code === field.value)?.name} (${field.value})` :
                                    field.value
                                  ) : (
                                    "Search and select region/CSC"
                                  )}
                                  <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                                </Button>
                              </div>
                            </FormControl>
                          </PopoverTrigger>
                          <PopoverContent className="w-full p-0" align="start">
                            <Command>
                              <CommandInput 
                                placeholder="Search regions or CSC codes..." 
                                onValueChange={setCSCSearchValue}
                                className="h-9"
                              />
                              <CommandList>
                                <CommandEmpty>No regions found</CommandEmpty>
                                <CommandGroup className="max-h-[300px] overflow-auto">
                                  {isLoadingRegions ? (
                                    <div className="p-2">
                                      <Skeleton className="h-8 w-full mb-2" />
                                      <Skeleton className="h-8 w-full mb-2" />
                                      <Skeleton className="h-8 w-full" />
                                    </div>
                                  ) : (
                                    filteredRegions.map((region) => (
                                      <CommandItem
                                        key={region.code}
                                        value={region.code}
                                        onSelect={() => {
                                          form.setValue("region", region.code);
                                          setOpenCSCCombobox(false);
                                        }}
                                        className="cursor-pointer"
                                      >
                                        <div className="flex items-center">
                                          <Check
                                            className={cn(
                                              "mr-2 h-4 w-4",
                                              field.value === region.code ? "opacity-100" : "opacity-0"
                                            )}
                                          />
                                          <span>{region.name}</span>
                                          <span className="ml-2 text-xs text-muted-foreground">({region.code})</span>
                                          {region.continent && (
                                            <span className="ml-auto text-xs text-muted-foreground">{region.continent}</span>
                                          )}
                                        </div>
                                      </CommandItem>
                                    ))
                                  )}
                                </CommandGroup>
                              </CommandList>
                            </Command>
                          </PopoverContent>
                        </Popover>
                        <FormDescription className="text-sm">
                          Search and select your device's region/CSC code
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}
              </motion.div>
              
              {/* Current Firmware */}
              <motion.div variants={fadeInUp(0.4)}>
                <FormField
                  control={form.control}
                  name="currentFirmware"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-base font-medium">
                        Current Firmware <span className="text-gray-400">(Optional)</span>
                      </FormLabel>
                      <FormControl>
                        <div className="relative">
                          <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-muted-foreground">
                            <i className="fas fa-code-branch"></i>
                          </span>
                          <Input 
                            placeholder="e.g., A546EXXU3AWG1" 
                            className="pl-10 py-6 border-gray-200 focus:border-primary focus:ring-2 focus:ring-primary"
                            {...field} 
                          />
                        </div>
                      </FormControl>
                      <FormDescription className="text-sm">
                        Enter your current firmware version if known
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </motion.div>
              
              {/* Knox Warranty Importance */}
              <motion.div variants={fadeInUp(0.5)}>
                <FormField
                  control={form.control}
                  name="knoxImportant"
                  render={({ field }) => (
                    <FormItem className="bg-gray-50 p-4 rounded-lg">
                      <FormLabel className="text-base font-medium">Knox Warranty Important?</FormLabel>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="flex flex-col sm:flex-row sm:space-x-6 space-y-2 sm:space-y-0 mt-2"
                        >
                          <div className="flex items-center space-x-2 bg-white rounded-md px-3 py-2 border border-gray-200">
                            <RadioGroupItem value="yes" id="knox-yes" />
                            <label htmlFor="knox-yes" className="font-medium">Yes, protect my warranty</label>
                          </div>
                          <div className="flex items-center space-x-2 bg-white rounded-md px-3 py-2 border border-gray-200">
                            <RadioGroupItem value="no" id="knox-no" />
                            <label htmlFor="knox-no" className="font-medium">No, I don't mind void warranty</label>
                          </div>
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </motion.div>
              
              <motion.div variants={fadeInUp(0.6)}>
                <Button 
                  type="submit" 
                  className="w-full py-6 px-4 bg-primary hover:bg-primary/90 text-white font-medium rounded-lg transition duration-300 text-base"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? (
                    <div className="flex items-center justify-center space-x-2">
                      <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      <span>Analyzing Compatibility...</span>
                    </div>
                  ) : 'Check Firmware Compatibility'}
                </Button>
              </motion.div>
              
              <motion.div 
                className="text-center text-muted-foreground text-sm"
                variants={fadeInUp(0.7)}
              >
                Your device information is only used for firmware analysis and is not stored permanently.
              </motion.div>
            </motion.form>
          </Form>
        </Card>
      </motion.div>
      
      {/* Right side illustration */}
      <motion.div 
        className="hidden md:block relative"
        initial="hidden"
        animate="visible"
        variants={fadeIn(0.3)}
      >
        <div className="sticky top-32">
          <div className="bg-gray-50 rounded-2xl p-8 h-full flex flex-col items-center justify-center">
            <div className="mb-6 text-center">
              <h3 className="text-lg font-semibold mb-3">Samsung Firmware Expert</h3>
              <p className="text-sm text-muted-foreground">
                Our AI analyzes compatibility for all Samsung models
              </p>
            </div>
            
            <div className="relative">
              <PhoneImage model="galaxy-s24" className="w-full max-w-[200px] mx-auto" animated={true} />
              
              <div className="absolute -right-4 top-1/4 bg-white rounded-lg shadow-md p-2 text-xs">
                <div className="flex items-center gap-2">
                  <div className="bg-green-100 rounded-full p-1">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-green-600" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <span>Compatible</span>
                </div>
              </div>
              
              <div className="absolute -left-4 bottom-1/4 bg-white rounded-lg shadow-md p-2 text-xs">
                <div className="flex items-center gap-2">
                  <div className="bg-yellow-100 rounded-full p-1">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 text-yellow-600" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <span>Knox Warning</span>
                </div>
              </div>
            </div>
            
            <div className="mt-8 space-y-3 w-full">
              <div className="bg-white rounded-lg p-3 shadow-sm">
                <div className="flex items-center">
                  <div className="bg-blue-100 rounded-full p-2 mr-3">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-blue-600" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-8-3a1 1 0 00-.867.5 1 1 0 11-1.731-1A3 3 0 0113 8a3.001 3.001 0 01-2 2.83V11a1 1 0 11-2 0v-1a1 1 0 011-1 1 1 0 100-2zm0 8a1 1 0 100-2 1 1 0 000 2z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-xs font-medium">Need Help?</p>
                    <p className="text-xs text-muted-foreground">Check our flashing guides</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
