import { Link } from 'wouter';
import { motion } from 'framer-motion';
import { FirmwareAnalysisResult } from '@shared/schema';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, AlertCircle, AlertTriangle, Download, BookOpen } from 'lucide-react';
import { fadeIn, fadeInUp, staggerContainer } from '@/lib/animations';

interface FirmwareResultsProps {
  deviceModel: string;
  deviceName?: string;
  result: FirmwareAnalysisResult;
}

export default function FirmwareResults({ deviceModel, deviceName, result }: FirmwareResultsProps) {
  const resultIsPositive = result.safetyAssessment.safeToFlash;
  
  return (
    <motion.div
      initial="hidden"
      animate="visible"
      variants={fadeIn()}
      className="mt-12"
    >
      <Card className="bg-white p-8 rounded-2xl shadow-xl border-0 overflow-hidden">
        <CardContent className="p-0">
          {/* Top status bar */}
          <div className={`absolute inset-x-0 top-0 h-2 ${resultIsPositive ? 'bg-gradient-to-r from-green-400 to-green-600' : 'bg-gradient-to-r from-red-400 to-red-600'}`}></div>
          
          <motion.div 
            className="border-b pb-6 pt-4 mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4"
            variants={fadeInUp(0.1)}
          >
            <div>
              <h3 className="text-2xl font-bold">Firmware Compatibility Analysis</h3>
              <p className="text-muted-foreground">
                Model: <span className="font-medium text-foreground">{deviceModel} {deviceName && `(${deviceName})`}</span>
              </p>
            </div>
            <div className={`flex items-center gap-2 px-4 py-2 rounded-full ${resultIsPositive ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>
              {resultIsPositive ? (
                <>
                  <CheckCircle className="h-5 w-5" />
                  <span className="font-semibold">Safe to Flash</span>
                </>
              ) : (
                <>
                  <AlertCircle className="h-5 w-5" />
                  <span className="font-semibold">Not Recommended</span>
                </>
              )}
            </div>
          </motion.div>
          
          <motion.div 
            className="space-y-8"
            variants={staggerContainer}
          >
            {/* Latest Compatible Firmware */}
            <motion.div variants={fadeInUp(0.2)}>
              <div className="mb-3 flex items-center">
                <div className="bg-primary/10 p-2 rounded-lg mr-3">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
                  </svg>
                </div>
                <h4 className="text-lg font-semibold">Latest Compatible Firmware</h4>
              </div>
              <div className="bg-gray-50 p-5 rounded-xl">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div className="bg-white p-4 rounded-lg shadow-sm">
                    <p className="text-sm text-muted-foreground mb-1">Version</p>
                    <p className="font-semibold text-lg">{result.latestFirmware.version}</p>
                  </div>
                  <div className="bg-white p-4 rounded-lg shadow-sm">
                    <p className="text-sm text-muted-foreground mb-1">Released</p>
                    <p className="font-semibold text-lg">{result.latestFirmware.released}</p>
                  </div>
                  <div className="bg-white p-4 rounded-lg shadow-sm">
                    <p className="text-sm text-muted-foreground mb-1">Size</p>
                    <p className="font-semibold text-lg">{result.latestFirmware.size}</p>
                  </div>
                </div>
              </div>
            </motion.div>
            
            {/* Compatibility Analysis */}
            <motion.div variants={fadeInUp(0.3)}>
              <div className="mb-3 flex items-center">
                <div className="bg-primary/10 p-2 rounded-lg mr-3">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M3.707 2.293a1 1 0 00-1.414 1.414l14 14a1 1 0 001.414-1.414l-1.473-1.473A10.014 10.014 0 0019.542 10C18.268 5.943 14.478 3 10 3a9.958 9.958 0 00-4.512 1.074l-1.78-1.781zm4.261 4.26l1.514 1.515a2.003 2.003 0 012.45 2.45l1.514 1.514a4 4 0 00-5.478-5.478z" clipRule="evenodd" />
                    <path d="M12.454 16.697L9.75 13.992a4 4 0 01-3.742-3.741L2.335 6.578A9.98 9.98 0 00.458 10c1.274 4.057 5.065 7 9.542 7 .847 0 1.669-.105 2.454-.303z" />
                  </svg>
                </div>
                <h4 className="text-lg font-semibold">Compatibility Analysis</h4>
              </div>
              <div className="bg-gray-50 p-5 rounded-xl space-y-4">
                <div className={`flex items-center p-3 rounded-lg ${result.compatibilityAnalysis.bootloaderCompatible ? 'bg-green-50' : 'bg-red-50'}`}>
                  <div className={`flex-shrink-0 w-8 h-8 rounded-full ${result.compatibilityAnalysis.bootloaderCompatible ? 'bg-green-100' : 'bg-red-100'} flex items-center justify-center`}>
                    {result.compatibilityAnalysis.bootloaderCompatible ? (
                      <CheckCircle className="h-5 w-5 text-green-600" />
                    ) : (
                      <AlertCircle className="h-5 w-5 text-red-600" />
                    )}
                  </div>
                  <div className="ml-4">
                    <p className={`font-medium ${result.compatibilityAnalysis.bootloaderCompatible ? 'text-green-800' : 'text-red-800'}`}>
                      Bootloader Compatibility
                    </p>
                    <p className={`text-sm ${result.compatibilityAnalysis.bootloaderCompatible ? 'text-green-700' : 'text-red-700'}`}>
                      Version: {result.compatibilityAnalysis.bootloaderVersion} - 
                      {result.compatibilityAnalysis.bootloaderCompatible ? ' Compatible' : ' Incompatible'}
                    </p>
                  </div>
                </div>
                
                <div className={`flex items-center p-3 rounded-lg ${result.compatibilityAnalysis.cscMatch ? 'bg-green-50' : 'bg-red-50'}`}>
                  <div className={`flex-shrink-0 w-8 h-8 rounded-full ${result.compatibilityAnalysis.cscMatch ? 'bg-green-100' : 'bg-red-100'} flex items-center justify-center`}>
                    {result.compatibilityAnalysis.cscMatch ? (
                      <CheckCircle className="h-5 w-5 text-green-600" />
                    ) : (
                      <AlertCircle className="h-5 w-5 text-red-600" />
                    )}
                  </div>
                  <div className="ml-4">
                    <p className={`font-medium ${result.compatibilityAnalysis.cscMatch ? 'text-green-800' : 'text-red-800'}`}>
                      CSC Region Match
                    </p>
                    <p className={`text-sm ${result.compatibilityAnalysis.cscMatch ? 'text-green-700' : 'text-red-700'}`}>
                      Region: {result.compatibilityAnalysis.cscRegion} - 
                      {result.compatibilityAnalysis.cscMatch ? ' Compatible' : ' Incompatible'}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center p-3 rounded-lg bg-amber-50">
                  <div className="flex-shrink-0 w-8 h-8 rounded-full bg-amber-100 flex items-center justify-center">
                    <AlertTriangle className="h-5 w-5 text-amber-600" />
                  </div>
                  <div className="ml-4">
                    <p className="font-medium text-amber-800">
                      Security Patch Level
                    </p>
                    <p className="text-sm text-amber-700">
                      Level: {result.compatibilityAnalysis.securityPatchLevel} - 
                      {result.compatibilityAnalysis.securityUpdate ? ' Will be updated' : ' Will remain the same'}
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
            
            {/* Safety Assessment */}
            <motion.div variants={fadeInUp(0.4)}>
              <div className="mb-3 flex items-center">
                <div className="bg-primary/10 p-2 rounded-lg mr-3">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                </div>
                <h4 className="text-lg font-semibold">Safety Assessment</h4>
              </div>
              <div className={`p-5 rounded-xl ${result.safetyAssessment.safeToFlash ? 'bg-green-50' : 'bg-red-50'} border ${result.safetyAssessment.safeToFlash ? 'border-green-200' : 'border-red-200'}`}>
                <div className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    {result.safetyAssessment.safeToFlash ? (
                      <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                        <CheckCircle className="h-6 w-6 text-green-600" />
                      </div>
                    ) : (
                      <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                        <AlertCircle className="h-6 w-6 text-red-600" />
                      </div>
                    )}
                  </div>
                  <div className="ml-4">
                    <h5 className={`text-lg font-semibold ${result.safetyAssessment.safeToFlash ? 'text-green-800' : 'text-red-800'}`}>
                      {result.safetyAssessment.safeToFlash ? 'Safe to Flash' : 'Unsafe to Flash'}
                    </h5>
                    <p className={`mt-1 ${result.safetyAssessment.safeToFlash ? 'text-green-700' : 'text-red-700'}`}>
                      {result.safetyAssessment.explanation}
                    </p>
                    
                    <div className="mt-3 p-3 bg-white rounded-lg shadow-sm">
                      <div className="flex items-center">
                        <div className={`w-6 h-6 rounded-full ${result.safetyAssessment.knoxSafe ? 'bg-green-100' : 'bg-yellow-100'} flex items-center justify-center mr-2`}>
                          {result.safetyAssessment.knoxSafe ? (
                            <CheckCircle className="h-4 w-4 text-green-600" />
                          ) : (
                            <AlertTriangle className="h-4 w-4 text-yellow-600" />
                          )}
                        </div>
                        <p className={`text-sm font-medium ${result.safetyAssessment.knoxSafe ? 'text-green-700' : 'text-yellow-700'}`}>
                          Knox Warranty: {result.safetyAssessment.knoxSafe ? 'Safe' : 'Will be voided'}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
            
            {/* Recommendations */}
            <motion.div variants={fadeInUp(0.5)}>
              <div className="mb-3 flex items-center">
                <div className="bg-primary/10 p-2 rounded-lg mr-3">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                  </svg>
                </div>
                <h4 className="text-lg font-semibold">Recommendations</h4>
              </div>
              <div className="bg-gray-50 p-5 rounded-xl">
                <ul className="space-y-3">
                  {result.recommendations.map((recommendation, index) => (
                    <li key={index} className="flex items-start">
                      <div className="flex-shrink-0 mt-1 mr-2">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-primary" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                      </div>
                      <p className="text-foreground">{recommendation}</p>
                    </li>
                  ))}
                </ul>
              </div>
            </motion.div>
            
            <motion.div 
              className="flex flex-col sm:flex-row gap-4 pt-4"
              variants={fadeInUp(0.6)}
            >
              <Button 
                className="bg-primary hover:bg-primary/90 text-white font-medium py-6 px-6"
                disabled={!resultIsPositive}
              >
                <Download className="mr-2 h-5 w-5" />
                Download Firmware
              </Button>
              <Link href="/flashing-guide">
                <Button variant="outline" className="font-medium py-6 px-6">
                  <BookOpen className="mr-2 h-5 w-5" />
                  View Flashing Guide
                </Button>
              </Link>
            </motion.div>
          </motion.div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
