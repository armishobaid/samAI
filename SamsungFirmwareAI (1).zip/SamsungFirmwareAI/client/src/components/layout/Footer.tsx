import { Link } from 'wouter';

export default function Footer() {
  return (
    <footer className="bg-gray-100 pt-16 pb-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          {/* Company Info */}
          <div className="md:col-span-1">
            <div className="flex items-center space-x-2 mb-6">
              <div className="w-10 h-10 rounded-lg gradient-bg flex items-center justify-center">
                <i className="fas fa-microchip text-white text-xl"></i>
              </div>
              <span className="text-xl font-bold text-foreground">SamFirms</span>
            </div>
            <p className="text-muted-foreground mb-6">
              AI-powered Samsung firmware compatibility analysis to keep your devices safe and functional.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-500 hover:text-primary transition">
                <i className="fab fa-twitter text-xl"></i>
              </a>
              <a href="#" className="text-gray-500 hover:text-primary transition">
                <i className="fab fa-facebook text-xl"></i>
              </a>
              <a href="#" className="text-gray-500 hover:text-primary transition">
                <i className="fab fa-instagram text-xl"></i>
              </a>
              <a href="#" className="text-gray-500 hover:text-primary transition">
                <i className="fab fa-youtube text-xl"></i>
              </a>
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Quick Links</h3>
            <ul className="space-y-4">
              <li>
                <Link href="/">
                  <span className="text-muted-foreground hover:text-primary transition cursor-pointer">Home</span>
                </Link>
              </li>
              <li>
                <Link href="/firmware-checker">
                  <span className="text-muted-foreground hover:text-primary transition cursor-pointer">Firmware Checker</span>
                </Link>
              </li>
              <li>
                <Link href="/flashing-guide">
                  <span className="text-muted-foreground hover:text-primary transition cursor-pointer">Flashing Guides</span>
                </Link>
              </li>
              <li>
                <Link href="/blog">
                  <span className="text-muted-foreground hover:text-primary transition cursor-pointer">Blog</span>
                </Link>
              </li>
              <li>
                <Link href="/#faq">
                  <span className="text-muted-foreground hover:text-primary transition cursor-pointer">FAQ</span>
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Legal Links */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Legal</h3>
            <ul className="space-y-4">
              <li>
                <Link href="/legal/terms">
                  <span className="text-muted-foreground hover:text-primary transition cursor-pointer">Terms of Service</span>
                </Link>
              </li>
              <li>
                <Link href="/legal/privacy">
                  <span className="text-muted-foreground hover:text-primary transition cursor-pointer">Privacy Policy</span>
                </Link>
              </li>
              <li>
                <Link href="/legal/disclaimer">
                  <span className="text-muted-foreground hover:text-primary transition cursor-pointer">Disclaimer</span>
                </Link>
              </li>
            </ul>
          </div>
          
          {/* Newsletter */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Subscribe</h3>
            <p className="text-muted-foreground mb-4">
              Get the latest firmware updates and compatibility alerts.
            </p>
            <form className="space-y-4">
              <div className="relative">
                <input 
                  type="email" 
                  placeholder="Your email address" 
                  className="w-full px-4 py-3 rounded-lg bg-white text-foreground border border-gray-200 focus:ring-2 focus:ring-primary focus:border-primary"
                />
                <button 
                  type="submit" 
                  className="absolute right-1 top-1 bg-primary hover:bg-primary/90 text-white py-2 px-4 rounded-lg font-medium transition-all duration-300"
                >
                  Subscribe
                </button>
              </div>
            </form>
          </div>
        </div>
        
        <div className="border-t border-gray-200 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-muted-foreground text-sm">
              &copy; {new Date().getFullYear()} SamFirms. All rights reserved. Not affiliated with Samsung.
            </p>
            <p className="text-muted-foreground text-sm mt-4 md:mt-0">
              Samsung is a registered trademark of Samsung Electronics Co., Ltd.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
