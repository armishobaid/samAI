import { Fragment } from 'react';
import { Link, useLocation } from 'wouter';
import { Dialog, Transition } from '@headlessui/react';
import { Button } from '@/components/ui/button';

interface MobileMenuProps {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
}

export default function MobileMenu({ isOpen, setIsOpen }: MobileMenuProps) {
  const [location] = useLocation();

  const handleLinkClick = () => {
    setIsOpen(false);
  };

  return (
    <Transition show={isOpen} as={Fragment}>
      <Dialog
        as="div"
        className="relative z-50"
        onClose={() => setIsOpen(false)}
      >
        <div className="fixed inset-0 bg-black/25" />

        <div className="fixed inset-y-0 right-0 z-50 w-full overflow-y-auto bg-white px-6 py-6 sm:max-w-sm sm:ring-1 sm:ring-gray-900/10">
          <div className="flex items-center justify-between">
            <Link href="/">
              <div className="flex items-center space-x-2 cursor-pointer" onClick={handleLinkClick}>
                <div className="w-10 h-10 rounded-lg gradient-bg flex items-center justify-center">
                  <i className="fas fa-microchip text-white text-xl"></i>
                </div>
                <span className="text-xl font-bold text-foreground">SamFirms</span>
              </div>
            </Link>
            <button
              type="button"
              className="-m-2.5 rounded-md p-2.5 text-gray-700"
              onClick={() => setIsOpen(false)}
            >
              <span className="sr-only">Close menu</span>
              <svg
                className="h-6 w-6"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth="1.5"
                stroke="currentColor"
                aria-hidden="true"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M6 18L18 6M6 6l12 12"
                />
              </svg>
            </button>
          </div>
          <div className="mt-6 flow-root">
            <div className="space-y-2 py-6">
              <Link href="/">
                <div 
                  className={`block rounded-lg px-3 py-2 text-base font-semibold leading-7 ${
                    location === "/" ? "text-primary" : "text-gray-900"
                  } hover:bg-gray-50 cursor-pointer`}
                  onClick={handleLinkClick}
                >
                  Home
                </div>
              </Link>
              <Link href="/firmware-checker">
                <div 
                  className={`block rounded-lg px-3 py-2 text-base font-semibold leading-7 ${
                    location === "/firmware-checker" ? "text-primary" : "text-gray-900"
                  } hover:bg-gray-50 cursor-pointer`}
                  onClick={handleLinkClick}
                >
                  Firmware Checker
                </div>
              </Link>
              <Link href="/flashing-guide">
                <div 
                  className={`block rounded-lg px-3 py-2 text-base font-semibold leading-7 ${
                    location === "/flashing-guide" ? "text-primary" : "text-gray-900"
                  } hover:bg-gray-50 cursor-pointer`}
                  onClick={handleLinkClick}
                >
                  Flashing Guide
                </div>
              </Link>
              <Link href="/blog">
                <div 
                  className={`block rounded-lg px-3 py-2 text-base font-semibold leading-7 ${
                    location === "/blog" ? "text-primary" : "text-gray-900"
                  } hover:bg-gray-50 cursor-pointer`}
                  onClick={handleLinkClick}
                >
                  Blog
                </div>
              </Link>
              <Link href="/#faq">
                <div 
                  className="block rounded-lg px-3 py-2 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50 cursor-pointer"
                  onClick={handleLinkClick}
                >
                  FAQs
                </div>
              </Link>
              <div className="py-6">
                <Link href="/firmware-checker">
                  <Button 
                    className="w-full bg-primary hover:bg-primary/90 text-white"
                    onClick={handleLinkClick}
                  >
                    Get Started
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </Dialog>
    </Transition>
  );
}
