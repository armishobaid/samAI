import { useState } from 'react';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import MobileMenu from './MobileMenu';

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 bg-white shadow-md">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <Link href="/">
            <div className="flex items-center space-x-2 cursor-pointer">
              <div className="w-10 h-10 rounded-lg gradient-bg flex items-center justify-center">
                <i className="fas fa-microchip text-white text-xl"></i>
              </div>
              <span className="text-xl font-bold text-foreground">SamFirms</span>
            </div>
          </Link>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/">
              <span className="nav-link cursor-pointer">Home</span>
            </Link>
            <Link href="/firmware-checker">
              <span className="nav-link cursor-pointer">Firmware Checker</span>
            </Link>
            <Link href="/flashing-guide">
              <span className="nav-link cursor-pointer">Flashing Guide</span>
            </Link>
            <Link href="/blog">
              <span className="nav-link cursor-pointer">Blog</span>
            </Link>
            <Link href="/#faq">
              <span className="nav-link cursor-pointer">FAQs</span>
            </Link>
            <Link href="/firmware-checker">
              <Button className="bg-primary hover:bg-primary/90 text-white">
                Get Started
              </Button>
            </Link>
          </nav>
          
          {/* Mobile menu button */}
          <button
            type="button"
            className="md:hidden text-foreground"
            onClick={() => setMobileMenuOpen(true)}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-6 w-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M4 6h16M4 12h16M4 18h16"
              />
            </svg>
          </button>
        </div>
      </div>

      {/* Mobile Navigation */}
      <MobileMenu isOpen={mobileMenuOpen} setIsOpen={setMobileMenuOpen} />
    </header>
  );
}
