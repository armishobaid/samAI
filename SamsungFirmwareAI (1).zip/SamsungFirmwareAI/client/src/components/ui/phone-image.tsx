import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface PhoneImageProps {
  model: string;
  className?: string;
  animated?: boolean;
}

export function PhoneImage({ model, className, animated = false }: PhoneImageProps) {
  const renderPhoneImage = () => {
    switch (model) {
      case 'galaxy-s24':
        return (
          <svg 
            viewBox="0 0 400 800" 
            xmlns="http://www.w3.org/2000/svg"
            className={cn("w-full h-full", className)}
          >
            {/* Phone frame */}
            <rect x="50" y="20" width="300" height="760" rx="40" fill="#f5f5f5" stroke="#e0e0e0" strokeWidth="2" />
            
            {/* Screen */}
            <rect x="65" y="60" width="270" height="680" rx="20" fill="#111" />
            
            {/* Camera cutout */}
            <circle cx="200" cy="90" r="10" fill="#333" />
            
            {/* Home bar */}
            <rect x="150" y="710" width="100" height="5" rx="2.5" fill="#555" />
            
            {/* Border shine effect */}
            <rect x="50" y="20" width="300" height="760" rx="40" fill="none" stroke="url(#shine)" strokeWidth="2" />
            
            {/* Screen content */}
            <g>
              {/* Abstract UI elements */}
              <rect x="90" y="130" width="220" height="40" rx="5" fill="#444" />
              <rect x="90" y="190" width="100" height="100" rx="5" fill="#444" />
              <rect x="210" y="190" width="100" height="100" rx="5" fill="#444" />
              <rect x="90" y="310" width="220" height="30" rx="5" fill="#444" />
              <rect x="90" y="360" width="220" height="30" rx="5" fill="#444" />
              <rect x="90" y="410" width="220" height="150" rx="5" fill="#444" />
              <rect x="90" y="580" width="100" height="40" rx="5" fill="#444" />
              <rect x="210" y="580" width="100" height="40" rx="5" fill="#444" />
              
              {/* Animated element if animated is true */}
              {animated && (
                <>
                  <motion.rect 
                    x="90" y="130" width="220" height="40" rx="5" 
                    fill="#2563eb" 
                    initial={{ opacity: 0.5 }}
                    animate={{ opacity: [0.5, 0.8, 0.5] }}
                    transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                  />
                  <motion.rect 
                    x="90" y="410" width="220" height="150" rx="5" 
                    fill="#2563eb" 
                    initial={{ opacity: 0.3 }}
                    animate={{ opacity: [0.3, 0.6, 0.3] }}
                    transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
                  />
                </>
              )}
            </g>
            
            {/* Gradient definition */}
            <defs>
              <linearGradient id="shine" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="rgba(255,255,255,0.5)" />
                <stop offset="50%" stopColor="rgba(255,255,255,0.1)" />
                <stop offset="100%" stopColor="rgba(255,255,255,0.5)" />
              </linearGradient>
            </defs>
          </svg>
        );
        
      case 'galaxy-fold':
        return (
          <svg 
            viewBox="0 0 420 800" 
            xmlns="http://www.w3.org/2000/svg"
            className={cn("w-full h-full", className)}
          >
            {/* Phone frame */}
            <rect x="60" y="20" width="300" height="760" rx="30" fill="#f1f1f1" stroke="#e0e0e0" strokeWidth="2" />
            
            {/* Fold line */}
            <line x1="210" y1="20" x2="210" y2="780" stroke="#e0e0e0" strokeWidth="4" />
            
            {/* Screen left */}
            <rect x="75" y="60" width="125" height="680" rx="10" fill="#111" />
            
            {/* Screen right */}
            <rect x="220" y="60" width="125" height="680" rx="10" fill="#111" />
            
            {/* Camera cutout */}
            <circle cx="210" cy="90" r="8" fill="#333" />
            
            {/* Screen content */}
            <g>
              {/* Left screen UI elements */}
              <rect x="90" y="130" width="95" height="30" rx="5" fill="#444" />
              <rect x="90" y="180" width="95" height="80" rx="5" fill="#444" />
              <rect x="90" y="280" width="95" height="30" rx="5" fill="#444" />
              <rect x="90" y="330" width="95" height="30" rx="5" fill="#444" />
              
              {/* Right screen UI elements */}
              <rect x="235" y="130" width="95" height="30" rx="5" fill="#444" />
              <rect x="235" y="180" width="95" height="180" rx="5" fill="#444" />
              <rect x="235" y="380" width="95" height="30" rx="5" fill="#444" />
              <rect x="235" y="430" width="95" height="30" rx="5" fill="#444" />
              
              {/* Animated elements if animated is true */}
              {animated && (
                <>
                  <motion.rect 
                    x="90" y="180" width="95" height="80" rx="5" 
                    fill="#2563eb" 
                    initial={{ opacity: 0.4 }}
                    animate={{ opacity: [0.4, 0.7, 0.4] }}
                    transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                  />
                  <motion.rect 
                    x="235" y="180" width="95" height="180" rx="5" 
                    fill="#2563eb" 
                    initial={{ opacity: 0.3 }}
                    animate={{ opacity: [0.3, 0.6, 0.3] }}
                    transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
                  />
                </>
              )}
            </g>
          </svg>
        );
        
      default: // Default to Galaxy S24
        return (
          <svg 
            viewBox="0 0 400 800" 
            xmlns="http://www.w3.org/2000/svg"
            className={cn("w-full h-full", className)}
          >
            {/* Phone frame */}
            <rect x="50" y="20" width="300" height="760" rx="40" fill="#f5f5f5" stroke="#e0e0e0" strokeWidth="2" />
            
            {/* Screen */}
            <rect x="65" y="60" width="270" height="680" rx="20" fill="#111" />
            
            {/* Camera cutout */}
            <circle cx="200" cy="90" r="10" fill="#333" />
            
            {/* Home bar */}
            <rect x="150" y="710" width="100" height="5" rx="2.5" fill="#555" />
            
            {/* Border shine effect */}
            <rect x="50" y="20" width="300" height="760" rx="40" fill="none" stroke="url(#shine)" strokeWidth="2" />
            
            {/* Screen content */}
            <g>
              {/* Abstract UI elements */}
              <rect x="90" y="130" width="220" height="40" rx="5" fill="#444" />
              <rect x="90" y="190" width="100" height="100" rx="5" fill="#444" />
              <rect x="210" y="190" width="100" height="100" rx="5" fill="#444" />
              <rect x="90" y="310" width="220" height="30" rx="5" fill="#444" />
              <rect x="90" y="360" width="220" height="30" rx="5" fill="#444" />
              <rect x="90" y="410" width="220" height="150" rx="5" fill="#444" />
              <rect x="90" y="580" width="100" height="40" rx="5" fill="#444" />
              <rect x="210" y="580" width="100" height="40" rx="5" fill="#444" />
              
              {/* Animated element if animated is true */}
              {animated && (
                <>
                  <motion.rect 
                    x="90" y="130" width="220" height="40" rx="5" 
                    fill="#2563eb" 
                    initial={{ opacity: 0.5 }}
                    animate={{ opacity: [0.5, 0.8, 0.5] }}
                    transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                  />
                  <motion.rect 
                    x="90" y="410" width="220" height="150" rx="5" 
                    fill="#2563eb" 
                    initial={{ opacity: 0.3 }}
                    animate={{ opacity: [0.3, 0.6, 0.3] }}
                    transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut", delay: 0.5 }}
                  />
                </>
              )}
            </g>
            
            {/* Gradient definition */}
            <defs>
              <linearGradient id="shine" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="rgba(255,255,255,0.5)" />
                <stop offset="50%" stopColor="rgba(255,255,255,0.1)" />
                <stop offset="100%" stopColor="rgba(255,255,255,0.5)" />
              </linearGradient>
            </defs>
          </svg>
        );
    }
  };

  return renderPhoneImage();
}