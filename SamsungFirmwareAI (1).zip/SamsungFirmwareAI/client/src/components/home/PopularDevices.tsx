import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { DeviceModel } from '@shared/schema';
import { Skeleton } from '@/components/ui/skeleton';

export default function PopularDevices() {
  const { data: devices, isLoading } = useQuery<DeviceModel[]>({
    queryKey: ['/api/device-models']
  });

  return (
    <section className="py-16">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Popular Samsung Devices</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Check compatibility for these popular Samsung models with just one click
          </p>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoading ? (
            // Loading skeletons
            Array(3).fill(0).map((_, index) => (
              <div key={index} className="bg-white rounded-xl shadow-lg overflow-hidden">
                <Skeleton className="w-full h-48" />
                <div className="p-6">
                  <Skeleton className="h-6 w-36 mb-2" />
                  <Skeleton className="h-4 w-24 mb-4" />
                  <div className="flex justify-between items-center">
                    <Skeleton className="h-6 w-20" />
                    <Skeleton className="h-6 w-32" />
                  </div>
                </div>
              </div>
            ))
          ) : (
            devices?.map((device) => (
              <div key={device.id} className="device-card bg-white rounded-xl shadow-lg overflow-hidden transition-all duration-300">
                <img 
                  src={device.imageUrl || "https://via.placeholder.com/800x500?text=Samsung+Device"} 
                  alt={`Samsung ${device.deviceName}`} 
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2">{device.deviceName}</h3>
                  <p className="text-sm text-muted-foreground mb-4">Model: {device.modelNumber}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium bg-muted py-1 px-3 rounded-full">One UI {device.oneUIVersion}</span>
                    <Link href={`/firmware-checker?model=${device.modelNumber}`}>
                      <a className="text-primary hover:text-primary/80 font-medium">
                        Check Firmware <i className="fas fa-arrow-right ml-1"></i>
                      </a>
                    </Link>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
        
        <div className="text-center mt-10">
          <Link href="/firmware-checker">
            <button className="bg-white border border-input hover:border-primary text-foreground hover:text-primary py-3 px-8 rounded-lg font-medium transition duration-300">
              View All Samsung Models
            </button>
          </Link>
        </div>
      </div>
    </section>
  );
}
