import { GradientText } from '@/components/ui/gradient-text';

export default function Features() {
  const features = [
    {
      icon: "shield-alt",
      title: "Knox Warranty Protection",
      description: "Protect your device's warranty by ensuring the firmware won't trigger Knox void flags."
    },
    {
      icon: "check-circle",
      title: "Bootloader Compatibility",
      description: "Verify bootloader version compatibility to prevent bricking your device during updates."
    },
    {
      icon: "globe",
      title: "Region-Specific Analysis",
      description: "Get region-specific CSC compatibility checks to ensure proper network functionality."
    }
  ];

  return (
    <section className="py-16 bg-gradient-to-b from-background to-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Why Use Our Firmware Checker?</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Our AI-powered tool ensures safe firmware updates for your Samsung device with comprehensive compatibility analysis.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow">
              <div className="w-12 h-12 rounded-lg gradient-bg flex items-center justify-center mb-4">
                <i className={`fas fa-${feature.icon} text-white text-xl`}></i>
              </div>
              <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
              <p className="text-muted-foreground">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
