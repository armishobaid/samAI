import { Link } from 'wouter';
import { Button } from '@/components/ui/button';

export default function CTA() {
  return (
    <section className="py-16 bg-gradient-to-r from-primary to-secondary">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center text-white">
          <h2 className="text-3xl font-bold mb-6">Ready to safely update your Samsung device?</h2>
          <p className="text-xl mb-8 opacity-90">
            Use our AI-powered firmware compatibility checker to prevent bricking and warranty issues.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link href="/firmware-checker">
              <Button 
                size="lg" 
                className="bg-white text-primary hover:bg-white/90 hover:text-primary"
              >
                Check Compatibility Now
              </Button>
            </Link>
            <Link href="/flashing-guide">
              <Button 
                size="lg" 
                variant="outline" 
                className="border-2 border-white text-white hover:bg-white hover:text-primary"
              >
                View Flashing Guides
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
