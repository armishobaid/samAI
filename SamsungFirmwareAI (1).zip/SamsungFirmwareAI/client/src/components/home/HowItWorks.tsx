export default function HowItWorks() {
  const steps = [
    {
      number: 1,
      title: "Enter Device Details",
      description: "Provide your Samsung model number, region and current firmware (if known)."
    },
    {
      number: 2,
      title: "AI Analysis",
      description: "Our AI analyzes bootloader, region, Knox compatibility and security risks."
    },
    {
      number: 3,
      title: "Get Results",
      description: "Receive detailed compatibility analysis and safe firmware recommendations."
    }
  ];

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">How Our Firmware Checker Works</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Our AI-powered solution provides accurate compatibility analysis in seconds
          </p>
        </div>
        
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {steps.map((step, index) => (
              <div key={index} className="bg-white p-6 rounded-xl shadow-lg relative">
                <div className="absolute -top-4 -left-4 w-10 h-10 rounded-full bg-primary flex items-center justify-center text-white font-bold">
                  {step.number}
                </div>
                <h3 className="text-xl font-semibold mb-3 mt-4">{step.title}</h3>
                <p className="text-muted-foreground">
                  {step.description}
                </p>
              </div>
            ))}
          </div>
          
          {/* Illustration */}
          <div className="mt-12 text-center">
            <img 
              src="https://pixabay.com/get/gb0d704b508000d366411623b2f53c8f880bed68741d1970012ed79e3aa2f1c787a16099551078a4515ddb4d420825c0461adbe56a1d50c41e2614532d4634046_1280.jpg" 
              alt="Firmware update technical illustration" 
              className="mx-auto rounded-xl shadow-lg max-w-full h-auto"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
