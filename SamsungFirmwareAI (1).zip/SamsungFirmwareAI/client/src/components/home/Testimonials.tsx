export default function Testimonials() {
  const testimonials = [
    {
      content: "This tool saved me from bricking my device! It warned me about bootloader incompatibility that I would have missed otherwise.",
      author: "Robert Chen",
      role: "Galaxy S21 Ultra Owner",
      initial: "R"
    },
    {
      content: "I was able to safely update my Galaxy A54 without losing Knox warranty thanks to your compatibility checker. A must-have tool!",
      author: "Sarah Johnson",
      role: "Galaxy A54 Owner",
      initial: "S"
    },
    {
      content: "The detailed explanations provided alongside the compatibility results helped me understand the firmware process better. Great work!",
      author: "Michael Torres",
      role: "Galaxy Z Fold 4 Owner",
      initial: "M"
    }
  ];

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">What Our Users Say</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Trusted by Samsung enthusiasts worldwide for safe firmware updates
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-white p-6 rounded-xl shadow-lg">
              <div className="flex items-center mb-4">
                <div className="text-accent">
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className="fas fa-star"></i>
                  <i className={index === 2 ? "fas fa-star-half-alt" : "fas fa-star"}></i>
                </div>
              </div>
              <p className="text-muted-foreground mb-6">
                "{testimonial.content}"
              </p>
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center text-primary font-bold">
                  {testimonial.initial}
                </div>
                <div className="ml-3">
                  <h4 className="font-medium">{testimonial.author}</h4>
                  <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
