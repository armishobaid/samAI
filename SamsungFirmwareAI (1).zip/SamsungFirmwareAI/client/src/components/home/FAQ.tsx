import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export default function FAQ() {
  const faqs = [
    {
      question: "What is firmware and why should I check compatibility?",
      answer: "Firmware is the operating system and software that runs on your Samsung device. Checking compatibility before flashing new firmware is crucial to prevent bricking your device, triggering Knox warranty void flags, or causing functionality issues. Our tool helps identify potential problems before you update."
    },
    {
      question: "How accurate is the compatibility check?",
      answer: "Our AI-powered compatibility checker uses a comprehensive database of Samsung device specifications, firmware versions, and known compatibility issues. It's over 98% accurate in predicting compatibility issues. However, we always recommend backing up your data before any firmware update."
    },
    {
      question: "What is Knox warranty and why is it important?",
      answer: "Samsung Knox is a security platform built into Samsung devices. The Knox warranty bit is a hardware-based security feature that permanently changes when unauthorized software is detected. Once triggered, certain features like Samsung Pay, Secure Folder, and warranty service may be permanently disabled. Our checker helps prevent actions that would trip this security feature."
    },
    {
      question: "Why is region/CSC important for firmware compatibility?",
      answer: "CSC (Country Specific Code) determines region-specific features, network settings, and pre-installed apps on your device. Flashing firmware with an incompatible CSC can cause network connectivity issues, missing features, or even render your device unusable in your region. Our tool checks CSC compatibility to ensure your device works properly after updating."
    },
    {
      question: "What is bootloader version and why does it matter?",
      answer: "The bootloader is the first software that runs when you turn on your device. Samsung implements a downgrade protection mechanism that prevents installing firmware with older bootloader versions. If you attempt to flash firmware with an incompatible bootloader version, you risk bricking your device. Our tool checks bootloader compatibility to prevent this situation."
    }
  ];

  return (
    <section className="py-16" id="faq">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Find answers to common questions about firmware compatibility and updates
          </p>
        </div>
        
        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`faq-${index}`}
                className="bg-white p-4 rounded-xl shadow-md"
              >
                <AccordionTrigger className="text-lg font-semibold text-left">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="pt-4 text-muted-foreground">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
}
