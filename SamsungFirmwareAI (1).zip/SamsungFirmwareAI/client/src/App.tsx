import { Switch, Route } from "wouter";
import { ThemeProvider } from "next-themes";
import Home from "@/pages/home";
import FirmwareCheckerPage from "@/pages/firmware-checker";
import FlashingGuidePage from "@/pages/flashing-guide";
import BlogIndexPage from "@/pages/blog/index";
import BlogPostPage from "@/pages/blog/post";
import TermsPage from "@/pages/legal/terms";
import PrivacyPage from "@/pages/legal/privacy";
import DisclaimerPage from "@/pages/legal/disclaimer";
import NotFound from "@/pages/not-found";
import { ChatSupport } from "@/components/chat/ChatSupport";

function App() {
  return (
    <ThemeProvider attribute="class" defaultTheme="light">
      {/* Chat Support is available on all pages */}
      <ChatSupport />
      
      <Switch>
        {/* Main Pages */}
        <Route path="/" component={Home} />
        <Route path="/firmware-checker" component={FirmwareCheckerPage} />
        <Route path="/flashing-guide" component={FlashingGuidePage} />
        
        {/* Blog Pages */}
        <Route path="/blog" component={BlogIndexPage} />
        <Route path="/blog/:slug" component={BlogPostPage} />
        
        {/* Legal Pages */}
        <Route path="/legal/terms" component={TermsPage} />
        <Route path="/legal/privacy" component={PrivacyPage} />
        <Route path="/legal/disclaimer" component={DisclaimerPage} />
        
        {/* Fallback to 404 */}
        <Route component={NotFound} />
      </Switch>
    </ThemeProvider>
  );
}

export default App;
