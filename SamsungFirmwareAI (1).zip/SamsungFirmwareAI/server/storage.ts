import {
  User,
  InsertUser,
  BlogPost,
  InsertBlogPost,
  DeviceModel,
  InsertDeviceModel,
  Region,
  InsertRegion,
  CompatibilityCheck,
  InsertCompatibilityCheck,
  SiteSetting,
  InsertSiteSetting,
  FirmwareAnalysisResult
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Blog posts methods
  getBlogPosts(): Promise<BlogPost[]>;
  getBlogPostById(id: number): Promise<BlogPost | undefined>;
  getBlogPostBySlug(slug: string): Promise<BlogPost | undefined>;
  createBlogPost(post: InsertBlogPost): Promise<BlogPost>;
  updateBlogPost(id: number, post: Partial<InsertBlogPost>): Promise<BlogPost | undefined>;
  deleteBlogPost(id: number): Promise<boolean>;

  // Device model methods
  getDeviceModels(): Promise<DeviceModel[]>;
  getDeviceModelById(id: number): Promise<DeviceModel | undefined>;
  getDeviceModelByModelNumber(modelNumber: string): Promise<DeviceModel | undefined>;
  createDeviceModel(model: InsertDeviceModel): Promise<DeviceModel>;
  updateDeviceModel(id: number, model: Partial<InsertDeviceModel>): Promise<DeviceModel | undefined>;

  // Region methods
  getRegions(): Promise<Region[]>;
  getRegionByCode(code: string): Promise<Region | undefined>;
  createRegion(region: InsertRegion): Promise<Region>;

  // Compatibility check methods
  getCompatibilityChecks(): Promise<CompatibilityCheck[]>;
  getCompatibilityCheckById(id: number): Promise<CompatibilityCheck | undefined>;
  createCompatibilityCheck(check: InsertCompatibilityCheck): Promise<CompatibilityCheck>;

  // Site settings methods
  getSiteSettings(): Promise<SiteSetting[]>;
  getSiteSettingByKey(key: string): Promise<SiteSetting | undefined>;
  createSiteSetting(setting: InsertSiteSetting): Promise<SiteSetting>;
  updateSiteSetting(key: string, value: string): Promise<SiteSetting | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private blogPosts: Map<number, BlogPost>;
  private deviceModels: Map<number, DeviceModel>;
  private regions: Map<number, Region>;
  private compatibilityChecks: Map<number, CompatibilityCheck>;
  private siteSettings: Map<number, SiteSetting>;

  private userId: number;
  private blogPostId: number;
  private deviceModelId: number;
  private regionId: number;
  private compatibilityCheckId: number;
  private siteSettingId: number;

  constructor() {
    this.users = new Map();
    this.blogPosts = new Map();
    this.deviceModels = new Map();
    this.regions = new Map();
    this.compatibilityChecks = new Map();
    this.siteSettings = new Map();

    this.userId = 1;
    this.blogPostId = 1;
    this.deviceModelId = 1;
    this.regionId = 1;
    this.compatibilityCheckId = 1;
    this.siteSettingId = 1;

    // Initialize with sample data
    this.initializeData();
  }

  private initializeData() {
    // Initialize regions
    const sampleRegions: InsertRegion[] = [
      { code: "INS", name: "India", continent: "Asia" },
      { code: "XEU", name: "Europe", continent: "Europe" },
      { code: "XSA", name: "South America", continent: "South America" },
      { code: "XAR", name: "United States", continent: "North America" },
      { code: "XSG", name: "UAE", continent: "Asia" },
      { code: "XME", name: "Middle East", continent: "Asia" },
    ];

    sampleRegions.forEach(region => this.createRegion(region));

    // Initialize device models
    const sampleDevices: InsertDeviceModel[] = [
      { modelNumber: "SM-G991B", deviceName: "Galaxy S21", imageUrl: "https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=500", releaseYear: 2021, latestFirmware: "G991BXXU3AWG1", oneUIVersion: "5.1" },
      { modelNumber: "SM-A546E", deviceName: "Galaxy A54", imageUrl: "https://images.unsplash.com/photo-1548094891-c4ba474efd16?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=500", releaseYear: 2023, latestFirmware: "A546EXXU3AWG1", oneUIVersion: "5.1" },
      { modelNumber: "SM-F936B", deviceName: "Galaxy Z Fold 4", imageUrl: "https://pixabay.com/get/ge683e8e01d526d8eb1b4d2ebc93c3e289a004a9414bc813300248d653c157bfac1d63b1d610a38e39d4cde748b2642ffdd0f94d6f83ec2dd561b5983a928e98a_1280.jpg", releaseYear: 2022, latestFirmware: "F936BXXU1AWG1", oneUIVersion: "5.1.1" },
    ];

    sampleDevices.forEach(device => this.createDeviceModel(device));

    // Initialize blog posts
    const sampleBlogPosts: InsertBlogPost[] = [
      {
        title: "Understanding Samsung CSC Codes: What They Mean For Your Device",
        slug: "understanding-samsung-csc-codes",
        content: `<p>CSC (Country Specific Code) is a critical part of Samsung firmware that determines region-specific features on your device. This comprehensive guide explains everything you need to know about Samsung CSC codes.</p>
        
        <h2>What is a CSC Code?</h2>
        <p>CSC codes are three-letter identifiers that specify the regional configuration of Samsung devices. These codes influence various aspects of your device, including:</p>
        <ul>
          <li>Pre-installed apps and bloatware</li>
          <li>Language options</li>
          <li>Cellular network configurations</li>
          <li>Samsung Pay availability</li>
          <li>Warranty validation</li>
          <li>Software update schedules</li>
        </ul>
        
        <h2>Common Samsung CSC Codes</h2>
        <p>Here are some of the most common CSC codes you'll encounter:</p>
        <ul>
          <li><strong>XSA</strong> - Australia</li>
          <li><strong>XEU</strong> - Europe (multi-CSC)</li>
          <li><strong>INS</strong> - India</li>
          <li><strong>XAR</strong> - United States (unlocked)</li>
          <li><strong>TMB</strong> - T-Mobile US</li>
          <li><strong>XSG</strong> - United Arab Emirates</li>
        </ul>
        
        <h2>Multi-CSC Firmware</h2>
        <p>Some Samsung firmware files contain multiple CSC codes (known as multi-CSC). For example, the XEU code represents several European countries. When you install a multi-CSC firmware, your device will automatically select the appropriate CSC based on your SIM card.</p>
        
        <h2>How CSC Affects Flashing</h2>
        <p>When flashing firmware, the CSC you choose determines which regional settings will be applied to your device. Using an incompatible CSC may cause functionality issues or warranty problems.</p>
        
        <h2>Checking Your Current CSC</h2>
        <p>To check the current CSC on your Samsung device, dial <code>*#1234#</code> in the phone app. This will display your current firmware version and CSC code.</p>
        
        <h2>Changing Your CSC</h2>
        <p>Changing your device's CSC typically requires flashing new firmware. However, this process can trip Knox security and void your warranty, so proceed with caution.</p>
        
        <h2>Use Our Firmware Checker</h2>
        <p>Before flashing any firmware, use our <a href="/firmware-checker">Firmware Compatibility Checker</a> to ensure you're using the right CSC for your device and region.</p>`,
        excerpt: "Learn everything about Samsung's Country Specific Codes (CSC), how they affect your device's features, and why they're crucial for firmware flashing.",
        featuredImage: "https://images.unsplash.com/photo-1563203369-26f2e4a5ccf7?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=500",
        published: true
      },
      {
        title: "How to Safely Flash Samsung Firmware Without Losing Data",
        slug: "safely-flash-samsung-firmware",
        content: `<p>Flashing new firmware on your Samsung device doesn't have to be risky. This guide walks you through the safest methods to update your device's firmware while preserving your personal data.</p>
        
        <h2>Before You Begin</h2>
        <p>Safety first! Here's what you should do before attempting to flash firmware:</p>
        <ul>
          <li>Back up all your important data using Samsung Smart Switch or Samsung Cloud</li>
          <li>Ensure your device has at least 60% battery</li>
          <li>Download the correct firmware for your specific model using a reliable source</li>
          <li>Verify firmware compatibility using our <a href="/firmware-checker">Firmware Checker tool</a></li>
        </ul>
        
        <h2>Method 1: Using Samsung Smart Switch</h2>
        <p>Samsung Smart Switch offers the safest way to update firmware:</p>
        <ol>
          <li>Install Samsung Smart Switch on your computer</li>
          <li>Connect your device via USB cable</li>
          <li>Select "Update" in Smart Switch</li>
          <li>Follow the on-screen instructions</li>
        </ol>
        <p>This method preserves all your data and has the lowest risk factor.</p>
        
        <h2>Method 2: Using Odin (Home CSC)</h2>
        <p>Odin allows more control over the flashing process:</p>
        <ol>
          <li>Download and install Odin on your PC</li>
          <li>Extract the firmware package to find the AP, BL, CP, and CSC files</li>
          <li>Boot your device into Download Mode (Power off + Volume Down + Bixby + Volume Up)</li>
          <li>Connect your device to the PC</li>
          <li>Add the firmware files to the appropriate slots in Odin</li>
          <li><strong>Important:</strong> Use HOME_CSC (not regular CSC) to preserve your data</li>
          <li>Click "Start" and wait for the process to complete</li>
        </ol>
        
        <h2>Method 3: Using ADB Sideload</h2>
        <p>For advanced users who prefer using ADB:</p>
        <ol>
          <li>Enable Developer Options and USB Debugging on your device</li>
          <li>Boot into Recovery Mode</li>
          <li>Select "Apply update from ADB"</li>
          <li>Use the command: <code>adb sideload firmware.zip</code></li>
        </ol>
        
        <h2>Troubleshooting Common Issues</h2>
        <p>If you encounter problems during flashing:</p>
        <ul>
          <li>Odin stuck at "Setup connection" - Try different USB ports or cables</li>
          <li>Bootloops - Boot into recovery and perform a cache wipe</li>
          <li>Verification failed - Re-download the firmware from a reliable source</li>
        </ul>
        
        <h2>Need Help?</h2>
        <p>Use our <a href="/">chat support</a> feature if you need assistance during the flashing process. Our experts are ready to help you safely navigate firmware installation.</p>`,
        excerpt: "Learn the safest methods to flash Samsung firmware without losing your personal data, photos, or settings with our step-by-step guide.",
        featuredImage: "https://images.unsplash.com/photo-1546027658-7aa750153465?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=500",
        published: true
      },
      {
        title: "What is Knox and Why Does it Matter When Flashing Firmware?",
        slug: "knox-security-explained",
        content: `<p>Samsung Knox is a sophisticated security platform that plays a critical role in keeping your device secure. Understanding how Knox works is essential before flashing custom firmware.</p>
        
        <h2>What is Samsung Knox?</h2>
        <p>Samsung Knox is a multi-layered security platform built into Samsung devices at the hardware and software level. It creates a secure environment that isolates sensitive data from potential threats.</p>
        
        <h2>The Knox Warranty Bit</h2>
        <p>One of the most important aspects of Knox for firmware enthusiasts is the Knox Warranty Bit (sometimes called the "Knox Counter"). This is a hardware-based security feature that permanently records if unauthorized software has been installed on the device.</p>
        
        <p>When the Knox Warranty Bit is tripped (changed from 0x0 to 0x1), several things happen:</p>
        <ul>
          <li>Your device warranty becomes void</li>
          <li>Knox-dependent apps like Samsung Pay and Secure Folder may stop working</li>
          <li>Your device can no longer be used for security-sensitive work applications</li>
          <li>Banking apps may detect the compromised security and refuse to work</li>
        </ul>
        
        <h2>What Trips Knox?</h2>
        <p>These actions typically trip the Knox Warranty Bit:</p>
        <ul>
          <li>Flashing unofficial or modified firmware</li>
          <li>Rooting the device</li>
          <li>Installing a custom recovery (like TWRP)</li>
          <li>Installing a custom kernel</li>
          <li>Downgrading to older bootloader versions</li>
        </ul>
        
        <h2>Safe Flashing and Knox</h2>
        <p>Not all firmware flashing will trip Knox. You can safely flash:</p>
        <ul>
          <li>Official firmware from Samsung (same model, same region)</li>
          <li>Official firmware with a newer bootloader version</li>
          <li>Firmware via Samsung Smart Switch</li>
        </ul>
        
        <h2>Checking Knox Status</h2>
        <p>To check if your Knox Warranty Bit has been tripped:</p>
        <ol>
          <li>Download the Phone Info SAM app from Google Play</li>
          <li>Go to the "Personal" tab</li>
          <li>Look for "Knox Warranty Void" - if it shows "0x0", Knox is intact; if "0x1", Knox has been tripped</li>
        </ol>
        
        <h2>Is It Worth Tripping Knox?</h2>
        <p>This depends on your priorities. If you rely on Samsung Pay, Secure Folder, or need your device for work in a BYOD environment, preserving Knox should be a priority. If these features aren't important to you, then the enhanced customization of custom ROMs might be worth the tradeoff.</p>
        
        <h2>Check Before You Flash</h2>
        <p>Our <a href="/firmware-checker">Firmware Compatibility Checker</a> can tell you whether a particular firmware installation is likely to trip Knox, helping you make informed decisions before flashing.</p>`,
        excerpt: "Learn about Samsung Knox security, how it protects your device, and why it matters when you're considering flashing new firmware.",
        featuredImage: "https://images.unsplash.com/photo-1633265486501-0cf524a07213?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=500",
        published: true
      }
    ];
    
    sampleBlogPosts.forEach(post => this.createBlogPost(post));

    // Initialize admin user
    this.createUser({
      username: "admin",
      password: "adminpass", // In a real app, this would be hashed
      isAdmin: true
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Blog posts methods
  async getBlogPosts(): Promise<BlogPost[]> {
    return Array.from(this.blogPosts.values());
  }

  async getBlogPostById(id: number): Promise<BlogPost | undefined> {
    return this.blogPosts.get(id);
  }

  async getBlogPostBySlug(slug: string): Promise<BlogPost | undefined> {
    return Array.from(this.blogPosts.values()).find(
      (post) => post.slug === slug
    );
  }

  async createBlogPost(insertPost: InsertBlogPost): Promise<BlogPost> {
    const id = this.blogPostId++;
    const now = new Date();
    const post: BlogPost = {
      ...insertPost,
      id,
      createdAt: now,
      updatedAt: now
    };
    this.blogPosts.set(id, post);
    return post;
  }

  async updateBlogPost(id: number, postUpdate: Partial<InsertBlogPost>): Promise<BlogPost | undefined> {
    const existingPost = this.blogPosts.get(id);
    if (!existingPost) return undefined;

    const updatedPost: BlogPost = {
      ...existingPost,
      ...postUpdate,
      updatedAt: new Date()
    };
    this.blogPosts.set(id, updatedPost);
    return updatedPost;
  }

  async deleteBlogPost(id: number): Promise<boolean> {
    return this.blogPosts.delete(id);
  }

  // Device model methods
  async getDeviceModels(): Promise<DeviceModel[]> {
    return Array.from(this.deviceModels.values());
  }

  async getDeviceModelById(id: number): Promise<DeviceModel | undefined> {
    return this.deviceModels.get(id);
  }

  async getDeviceModelByModelNumber(modelNumber: string): Promise<DeviceModel | undefined> {
    return Array.from(this.deviceModels.values()).find(
      (model) => model.modelNumber.toLowerCase() === modelNumber.toLowerCase()
    );
  }

  async createDeviceModel(insertModel: InsertDeviceModel): Promise<DeviceModel> {
    const id = this.deviceModelId++;
    const model: DeviceModel = { ...insertModel, id };
    this.deviceModels.set(id, model);
    return model;
  }

  async updateDeviceModel(id: number, modelUpdate: Partial<InsertDeviceModel>): Promise<DeviceModel | undefined> {
    const existingModel = this.deviceModels.get(id);
    if (!existingModel) return undefined;

    const updatedModel: DeviceModel = {
      ...existingModel,
      ...modelUpdate
    };
    this.deviceModels.set(id, updatedModel);
    return updatedModel;
  }

  // Region methods
  async getRegions(): Promise<Region[]> {
    return Array.from(this.regions.values());
  }

  async getRegionByCode(code: string): Promise<Region | undefined> {
    return Array.from(this.regions.values()).find(
      (region) => region.code === code
    );
  }

  async createRegion(insertRegion: InsertRegion): Promise<Region> {
    const id = this.regionId++;
    const region: Region = { ...insertRegion, id };
    this.regions.set(id, region);
    return region;
  }

  // Compatibility check methods
  async getCompatibilityChecks(): Promise<CompatibilityCheck[]> {
    return Array.from(this.compatibilityChecks.values());
  }

  async getCompatibilityCheckById(id: number): Promise<CompatibilityCheck | undefined> {
    return this.compatibilityChecks.get(id);
  }

  async createCompatibilityCheck(insertCheck: InsertCompatibilityCheck): Promise<CompatibilityCheck> {
    const id = this.compatibilityCheckId++;
    const check: CompatibilityCheck = {
      ...insertCheck,
      id,
      createdAt: new Date()
    };
    this.compatibilityChecks.set(id, check);
    return check;
  }

  // Site settings methods
  async getSiteSettings(): Promise<SiteSetting[]> {
    return Array.from(this.siteSettings.values());
  }

  async getSiteSettingByKey(key: string): Promise<SiteSetting | undefined> {
    return Array.from(this.siteSettings.values()).find(
      (setting) => setting.settingKey === key
    );
  }

  async createSiteSetting(insertSetting: InsertSiteSetting): Promise<SiteSetting> {
    const id = this.siteSettingId++;
    const setting: SiteSetting = {
      ...insertSetting,
      id,
      lastUpdated: new Date()
    };
    this.siteSettings.set(id, setting);
    return setting;
  }

  async updateSiteSetting(key: string, value: string): Promise<SiteSetting | undefined> {
    const existingSetting = Array.from(this.siteSettings.values()).find(
      (setting) => setting.settingKey === key
    );
    
    if (!existingSetting) return undefined;

    const updatedSetting: SiteSetting = {
      ...existingSetting,
      settingValue: value,
      lastUpdated: new Date()
    };
    this.siteSettings.set(existingSetting.id, updatedSetting);
    return updatedSetting;
  }
}

// Import the DatabaseStorage implementation
import { DatabaseStorage } from "./databaseStorage";

// Create and export the storage instance
export const storage = new DatabaseStorage();
