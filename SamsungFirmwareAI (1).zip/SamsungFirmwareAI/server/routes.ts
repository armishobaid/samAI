import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertBlogPostSchema, insertDeviceModelSchema, insertRegionSchema, insertCompatibilityCheckSchema, insertSiteSettingSchema } from "@shared/schema";
import { z } from "zod";
import { fromZodError } from "zod-validation-error";
import { analyzeFirmwareCompatibility } from "./utils/openai";

export async function registerRoutes(app: Express): Promise<Server> {
  // prefix all routes with /api
  const apiRouter = app.route("/api");

  // === Device Models Routes ===
  app.get("/api/device-models", async (_req: Request, res: Response) => {
    try {
      const models = await storage.getDeviceModels();
      res.json(models);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch device models" });
    }
  });

  app.get("/api/device-models/:modelNumber", async (req: Request, res: Response) => {
    try {
      const modelNumber = req.params.modelNumber;
      const model = await storage.getDeviceModelByModelNumber(modelNumber);
      
      if (!model) {
        return res.status(404).json({ message: "Device model not found" });
      }
      
      res.json(model);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch device model" });
    }
  });

  app.post("/api/device-models", async (req: Request, res: Response) => {
    try {
      const validatedData = insertDeviceModelSchema.parse(req.body);
      const newModel = await storage.createDeviceModel(validatedData);
      res.status(201).json(newModel);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data provided" });
      }
      res.status(500).json({ message: "Failed to create device model" });
    }
  });

  // === Regions Routes ===
  app.get("/api/regions", async (_req: Request, res: Response) => {
    try {
      const regions = await storage.getRegions();
      res.json(regions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch regions" });
    }
  });

  app.get("/api/regions/:code", async (req: Request, res: Response) => {
    try {
      const code = req.params.code;
      const region = await storage.getRegionByCode(code);
      
      if (!region) {
        return res.status(404).json({ message: "Region not found" });
      }
      
      res.json(region);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch region" });
    }
  });

  app.post("/api/regions", async (req: Request, res: Response) => {
    try {
      const validatedData = insertRegionSchema.parse(req.body);
      const newRegion = await storage.createRegion(validatedData);
      res.status(201).json(newRegion);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data provided" });
      }
      res.status(500).json({ message: "Failed to create region" });
    }
  });

  // === Blog Posts Routes ===
  app.get("/api/blog-posts", async (_req: Request, res: Response) => {
    try {
      const posts = await storage.getBlogPosts();
      res.json(posts);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch blog posts" });
    }
  });

  app.get("/api/blog-posts/:slug", async (req: Request, res: Response) => {
    try {
      const slug = req.params.slug;
      const post = await storage.getBlogPostBySlug(slug);
      
      if (!post) {
        return res.status(404).json({ message: "Blog post not found" });
      }
      
      res.json(post);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch blog post" });
    }
  });

  app.post("/api/blog-posts", async (req: Request, res: Response) => {
    try {
      const validatedData = insertBlogPostSchema.parse(req.body);
      const newPost = await storage.createBlogPost(validatedData);
      res.status(201).json(newPost);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data provided" });
      }
      res.status(500).json({ message: "Failed to create blog post" });
    }
  });

  app.put("/api/blog-posts/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      const validatedData = insertBlogPostSchema.partial().parse(req.body);
      const updatedPost = await storage.updateBlogPost(id, validatedData);
      
      if (!updatedPost) {
        return res.status(404).json({ message: "Blog post not found" });
      }
      
      res.json(updatedPost);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data provided" });
      }
      res.status(500).json({ message: "Failed to update blog post" });
    }
  });

  app.delete("/api/blog-posts/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID" });
      }
      
      const success = await storage.deleteBlogPost(id);
      
      if (!success) {
        return res.status(404).json({ message: "Blog post not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete blog post" });
    }
  });

  // === Firmware Compatibility Check ===
  app.post("/api/firmware-check", async (req: Request, res: Response) => {
    try {
      const firmwareCheckSchema = z.object({
        deviceModel: z.string().min(1),
        region: z.string().min(1),
        currentFirmware: z.string().optional(),
        knoxImportant: z.boolean().default(true)
      });
      
      const validatedData = firmwareCheckSchema.parse(req.body);
      
      // Call OpenAI to analyze firmware compatibility
      const analysisResult = await analyzeFirmwareCompatibility(validatedData);
      
      // Store the check history
      const checkData = {
        deviceModel: validatedData.deviceModel,
        region: validatedData.region,
        currentFirmware: validatedData.currentFirmware,
        knoxImportant: validatedData.knoxImportant,
        resultData: analysisResult
      };
      
      await storage.createCompatibilityCheck(checkData);
      
      res.json(analysisResult);
    } catch (error) {
      console.error("Firmware check error:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data provided" });
      }
      res.status(500).json({ message: "Failed to analyze firmware compatibility" });
    }
  });

  // === Site Settings Routes ===
  app.get("/api/site-settings", async (_req: Request, res: Response) => {
    try {
      const settings = await storage.getSiteSettings();
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch site settings" });
    }
  });

  app.get("/api/site-settings/:key", async (req: Request, res: Response) => {
    try {
      const key = req.params.key;
      const setting = await storage.getSiteSettingByKey(key);
      
      if (!setting) {
        return res.status(404).json({ message: "Setting not found" });
      }
      
      res.json(setting);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch setting" });
    }
  });

  app.post("/api/site-settings", async (req: Request, res: Response) => {
    try {
      const validatedData = insertSiteSettingSchema.parse(req.body);
      const newSetting = await storage.createSiteSetting(validatedData);
      res.status(201).json(newSetting);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid data provided" });
      }
      res.status(500).json({ message: "Failed to create site setting" });
    }
  });

  app.put("/api/site-settings/:key", async (req: Request, res: Response) => {
    try {
      const key = req.params.key;
      const { value } = req.body;
      
      if (typeof value !== 'string') {
        return res.status(400).json({ message: "Value must be a string" });
      }
      
      const updatedSetting = await storage.updateSiteSetting(key, value);
      
      if (!updatedSetting) {
        return res.status(404).json({ message: "Setting not found" });
      }
      
      res.json(updatedSetting);
    } catch (error) {
      res.status(500).json({ message: "Failed to update setting" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
