import { eq, desc } from "drizzle-orm";
import { db } from "./db";
import {
  users,
  blogPosts,
  deviceModels,
  regions,
  compatibilityChecks,
  siteSettings,
  type User,
  type InsertUser,
  type BlogPost,
  type InsertBlogPost,
  type DeviceModel,
  type InsertDeviceModel,
  type Region,
  type InsertRegion,
  type CompatibilityCheck,
  type InsertCompatibilityCheck,
  type SiteSetting,
  type InsertSiteSetting,
} from "@shared/schema";
import { IStorage } from "./storage";

export class DatabaseStorage implements IStorage {
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  // Blog posts methods
  async getBlogPosts(): Promise<BlogPost[]> {
    return await db.select().from(blogPosts).orderBy(desc(blogPosts.createdAt));
  }

  async getBlogPostById(id: number): Promise<BlogPost | undefined> {
    const [post] = await db.select().from(blogPosts).where(eq(blogPosts.id, id));
    return post;
  }

  async getBlogPostBySlug(slug: string): Promise<BlogPost | undefined> {
    const [post] = await db.select().from(blogPosts).where(eq(blogPosts.slug, slug));
    return post;
  }

  async createBlogPost(post: InsertBlogPost): Promise<BlogPost> {
    const [newPost] = await db.insert(blogPosts).values(post).returning();
    return newPost;
  }

  async updateBlogPost(id: number, postUpdate: Partial<InsertBlogPost>): Promise<BlogPost | undefined> {
    const [updatedPost] = await db
      .update(blogPosts)
      .set(postUpdate)
      .where(eq(blogPosts.id, id))
      .returning();
    return updatedPost;
  }

  async deleteBlogPost(id: number): Promise<boolean> {
    const [deletedPost] = await db
      .delete(blogPosts)
      .where(eq(blogPosts.id, id))
      .returning({ id: blogPosts.id });
    return !!deletedPost;
  }

  // Device model methods
  async getDeviceModels(): Promise<DeviceModel[]> {
    return await db.select().from(deviceModels);
  }

  async getDeviceModelById(id: number): Promise<DeviceModel | undefined> {
    const [model] = await db.select().from(deviceModels).where(eq(deviceModels.id, id));
    return model;
  }

  async getDeviceModelByModelNumber(modelNumber: string): Promise<DeviceModel | undefined> {
    const [model] = await db
      .select()
      .from(deviceModels)
      .where(eq(deviceModels.modelNumber, modelNumber));
    return model;
  }

  async createDeviceModel(model: InsertDeviceModel): Promise<DeviceModel> {
    const [newModel] = await db.insert(deviceModels).values(model).returning();
    return newModel;
  }

  async updateDeviceModel(id: number, modelUpdate: Partial<InsertDeviceModel>): Promise<DeviceModel | undefined> {
    const [updatedModel] = await db
      .update(deviceModels)
      .set(modelUpdate)
      .where(eq(deviceModels.id, id))
      .returning();
    return updatedModel;
  }

  // Region methods
  async getRegions(): Promise<Region[]> {
    return await db.select().from(regions);
  }

  async getRegionByCode(code: string): Promise<Region | undefined> {
    const [region] = await db.select().from(regions).where(eq(regions.code, code));
    return region;
  }

  async createRegion(region: InsertRegion): Promise<Region> {
    const [newRegion] = await db.insert(regions).values(region).returning();
    return newRegion;
  }

  // Compatibility check methods
  async getCompatibilityChecks(): Promise<CompatibilityCheck[]> {
    return await db
      .select()
      .from(compatibilityChecks)
      .orderBy(desc(compatibilityChecks.createdAt));
  }

  async getCompatibilityCheckById(id: number): Promise<CompatibilityCheck | undefined> {
    const [check] = await db
      .select()
      .from(compatibilityChecks)
      .where(eq(compatibilityChecks.id, id));
    return check;
  }

  async createCompatibilityCheck(check: InsertCompatibilityCheck): Promise<CompatibilityCheck> {
    const [newCheck] = await db
      .insert(compatibilityChecks)
      .values(check)
      .returning();
    return newCheck;
  }

  // Site settings methods
  async getSiteSettings(): Promise<SiteSetting[]> {
    return await db.select().from(siteSettings);
  }

  async getSiteSettingByKey(key: string): Promise<SiteSetting | undefined> {
    const [setting] = await db
      .select()
      .from(siteSettings)
      .where(eq(siteSettings.settingKey, key));
    return setting;
  }

  async createSiteSetting(setting: InsertSiteSetting): Promise<SiteSetting> {
    const [newSetting] = await db
      .insert(siteSettings)
      .values(setting)
      .returning();
    return newSetting;
  }

  async updateSiteSetting(key: string, value: string): Promise<SiteSetting | undefined> {
    const [updatedSetting] = await db
      .update(siteSettings)
      .set({ 
        settingValue: value,
        lastUpdated: new Date()
      })
      .where(eq(siteSettings.settingKey, key))
      .returning();
    return updatedSetting;
  }
}