// This script seeds the database with initial data

import { db } from "../server/db";
import {
  users,
  blogPosts,
  deviceModels,
  regions,
  siteSettings,
  type InsertUser,
  type InsertBlogPost,
  type InsertDeviceModel,
  type InsertRegion,
  type InsertSiteSetting,
} from "../shared/schema";

async function main() {
  console.log("🌱 Seeding database...");

  // Seed users
  console.log("Seeding users...");
  const adminUser: InsertUser = {
    username: "admin",
    password: "adminpass", // In a real app, this would be hashed
    isAdmin: true
  };
  await db.insert(users).values(adminUser).onConflictDoNothing();

  // Seed regions
  console.log("Seeding regions...");
  const sampleRegions: InsertRegion[] = [
    { code: "INS", name: "India", continent: "Asia" },
    { code: "XEU", name: "Europe", continent: "Europe" },
    { code: "XSA", name: "South America", continent: "South America" },
    { code: "XAR", name: "United States", continent: "North America" },
    { code: "XSG", name: "UAE", continent: "Asia" },
    { code: "XME", name: "Middle East", continent: "Asia" },
  ];
  
  for (const region of sampleRegions) {
    await db.insert(regions).values(region).onConflictDoNothing();
  }

  // Seed device models
  console.log("Seeding device models...");
  const sampleDevices: InsertDeviceModel[] = [
    { modelNumber: "SM-G991B", deviceName: "Galaxy S21", imageUrl: "https://images.unsplash.com/photo-1610945415295-d9bbf067e59c?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=500", releaseYear: 2021, latestFirmware: "G991BXXU3AWG1", oneUIVersion: "5.1" },
    { modelNumber: "SM-A546E", deviceName: "Galaxy A54", imageUrl: "https://images.unsplash.com/photo-1548094891-c4ba474efd16?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=500", releaseYear: 2023, latestFirmware: "A546EXXU3AWG1", oneUIVersion: "5.1" },
    { modelNumber: "SM-F936B", deviceName: "Galaxy Z Fold 4", imageUrl: "https://pixabay.com/get/ge683e8e01d526d8eb1b4d2ebc93c3e289a004a9414bc813300248d653c157bfac1d63b1d610a38e39d4cde748b2642ffdd0f94d6f83ec2dd561b5983a928e98a_1280.jpg", releaseYear: 2022, latestFirmware: "F936BXXU1AWG1", oneUIVersion: "5.1.1" },
    { modelNumber: "SM-G998B", deviceName: "Galaxy S21 Ultra 5G", imageUrl: "https://images.unsplash.com/photo-1610945264803-c22b62d2a7b3?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=500", releaseYear: 2021, latestFirmware: "G998BXXS9EWC1", oneUIVersion: "5.1" },
    { modelNumber: "SM-S901B", deviceName: "Galaxy S22 5G", imageUrl: "https://images.unsplash.com/photo-1655843311950-fd73e76e4bd0?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=500", releaseYear: 2022, latestFirmware: "S901BXXS3CWB9", oneUIVersion: "5.1" },
    { modelNumber: "SM-S908B", deviceName: "Galaxy S22 Ultra 5G", imageUrl: "https://images.unsplash.com/photo-1655843311950-fd73e76e4bd0?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=500", releaseYear: 2022, latestFirmware: "S908BXXS3CWB9", oneUIVersion: "5.1" },
  ];
  
  for (const device of sampleDevices) {
    await db.insert(deviceModels).values(device).onConflictDoNothing();
  }

  // Seed blog posts
  console.log("Seeding blog posts...");
  const sampleBlogPosts: InsertBlogPost[] = [
    {
      title: "Understanding Samsung CSC Codes: What They Mean For Your Device",
      slug: "understanding-samsung-csc-codes",
      content: `<p>CSC (Country Specific Code) is a critical part of Samsung firmware that determines region-specific features on your device. This comprehensive guide explains everything you need to know about Samsung CSC codes.</p>
      
      <h2>What is a CSC Code?</h2>
      <p>CSC codes are three-letter identifiers that specify the regional configuration of Samsung devices. These codes influence various aspects of your device, including:</p>
      <ul>
        <li>Pre-installed apps and bloatware</li>
        <li>Language options</li>
        <li>Cellular network configurations</li>
        <li>Samsung Pay availability</li>
        <li>Warranty validation</li>
        <li>Software update schedules</li>
      </ul>
      
      <h2>Common Samsung CSC Codes</h2>
      <p>Here are some of the most common CSC codes you'll encounter:</p>
      <ul>
        <li><strong>XSA</strong> - Australia</li>
        <li><strong>XEU</strong> - Europe (multi-CSC)</li>
        <li><strong>INS</strong> - India</li>
        <li><strong>XAR</strong> - United States (unlocked)</li>
        <li><strong>TMB</strong> - T-Mobile US</li>
        <li><strong>XSG</strong> - United Arab Emirates</li>
      </ul>
      
      <h2>Multi-CSC Firmware</h2>
      <p>Some Samsung firmware files contain multiple CSC codes (known as multi-CSC). For example, the XEU code represents several European countries. When you install a multi-CSC firmware, your device will automatically select the appropriate CSC based on your SIM card.</p>
      
      <h2>How CSC Affects Flashing</h2>
      <p>When flashing firmware, the CSC you choose determines which regional settings will be applied to your device. Using an incompatible CSC may cause functionality issues or warranty problems.</p>
      
      <h2>Checking Your Current CSC</h2>
      <p>To check the current CSC on your Samsung device, dial <code>*#1234#</code> in the phone app. This will display your current firmware version and CSC code.</p>
      
      <h2>Changing Your CSC</h2>
      <p>Changing your device's CSC typically requires flashing new firmware. However, this process can trip Knox security and void your warranty, so proceed with caution.</p>
      
      <h2>Use Our Firmware Checker</h2>
      <p>Before flashing any firmware, use our <a href="/firmware-checker">Firmware Compatibility Checker</a> to ensure you're using the right CSC for your device and region.</p>`,
      excerpt: "Learn everything about Samsung's Country Specific Codes (CSC), how they affect your device's features, and why they're crucial for firmware flashing.",
      featuredImage: "https://images.unsplash.com/photo-1563203369-26f2e4a5ccf7?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=500",
      published: true
    },
    {
      title: "How to Safely Flash Samsung Firmware Without Losing Data",
      slug: "safely-flash-samsung-firmware",
      content: `<p>Flashing new firmware on your Samsung device doesn't have to be risky. This guide walks you through the safest methods to update your device's firmware while preserving your personal data.</p>
      
      <h2>Before You Begin</h2>
      <p>Safety first! Here's what you should do before attempting to flash firmware:</p>
      <ul>
        <li>Back up all your important data using Samsung Smart Switch or Samsung Cloud</li>
        <li>Ensure your device has at least 60% battery</li>
        <li>Download the correct firmware for your specific model using a reliable source</li>
        <li>Verify firmware compatibility using our <a href="/firmware-checker">Firmware Checker tool</a></li>
      </ul>
      
      <h2>Method 1: Using Samsung Smart Switch</h2>
      <p>Samsung Smart Switch offers the safest way to update firmware:</p>
      <ol>
        <li>Install Samsung Smart Switch on your computer</li>
        <li>Connect your device via USB cable</li>
        <li>Select "Update" in Smart Switch</li>
        <li>Follow the on-screen instructions</li>
      </ol>
      <p>This method preserves all your data and has the lowest risk factor.</p>
      
      <h2>Method 2: Using Odin (Home CSC)</h2>
      <p>Odin allows more control over the flashing process:</p>
      <ol>
        <li>Download and install Odin on your PC</li>
        <li>Extract the firmware package to find the AP, BL, CP, and CSC files</li>
        <li>Boot your device into Download Mode (Power off + Volume Down + Bixby + Volume Up)</li>
        <li>Connect your device to the PC</li>
        <li>Add the firmware files to the appropriate slots in Odin</li>
        <li><strong>Important:</strong> Use HOME_CSC (not regular CSC) to preserve your data</li>
        <li>Click "Start" and wait for the process to complete</li>
      </ol>
      
      <h2>Method 3: Using ADB Sideload</h2>
      <p>For advanced users who prefer using ADB:</p>
      <ol>
        <li>Enable Developer Options and USB Debugging on your device</li>
        <li>Boot into Recovery Mode</li>
        <li>Select "Apply update from ADB"</li>
        <li>Use the command: <code>adb sideload firmware.zip</code></li>
      </ol>
      
      <h2>Troubleshooting Common Issues</h2>
      <p>If you encounter problems during flashing:</p>
      <ul>
        <li>Odin stuck at "Setup connection" - Try different USB ports or cables</li>
        <li>Bootloops - Boot into recovery and perform a cache wipe</li>
        <li>Verification failed - Re-download the firmware from a reliable source</li>
      </ul>
      
      <h2>Need Help?</h2>
      <p>Use our <a href="/">chat support</a> feature if you need assistance during the flashing process. Our experts are ready to help you safely navigate firmware installation.</p>`,
      excerpt: "Learn the safest methods to flash Samsung firmware without losing your personal data, photos, or settings with our step-by-step guide.",
      featuredImage: "https://images.unsplash.com/photo-1546027658-7aa750153465?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=500",
      published: true
    },
    {
      title: "What is Knox and Why Does it Matter When Flashing Firmware?",
      slug: "knox-security-explained",
      content: `<p>Samsung Knox is a sophisticated security platform that plays a critical role in keeping your device secure. Understanding how Knox works is essential before flashing custom firmware.</p>
      
      <h2>What is Samsung Knox?</h2>
      <p>Samsung Knox is a multi-layered security platform built into Samsung devices at the hardware and software level. It creates a secure environment that isolates sensitive data from potential threats.</p>
      
      <h2>The Knox Warranty Bit</h2>
      <p>One of the most important aspects of Knox for firmware enthusiasts is the Knox Warranty Bit (sometimes called the "Knox Counter"). This is a hardware-based security feature that permanently records if unauthorized software has been installed on the device.</p>
      
      <p>When the Knox Warranty Bit is tripped (changed from 0x0 to 0x1), several things happen:</p>
      <ul>
        <li>Your device warranty becomes void</li>
        <li>Knox-dependent apps like Samsung Pay and Secure Folder may stop working</li>
        <li>Your device can no longer be used for security-sensitive work applications</li>
        <li>Banking apps may detect the compromised security and refuse to work</li>
      </ul>
      
      <h2>What Trips Knox?</h2>
      <p>These actions typically trip the Knox Warranty Bit:</p>
      <ul>
        <li>Flashing unofficial or modified firmware</li>
        <li>Rooting the device</li>
        <li>Installing a custom recovery (like TWRP)</li>
        <li>Installing a custom kernel</li>
        <li>Downgrading to older bootloader versions</li>
      </ul>
      
      <h2>Safe Flashing and Knox</h2>
      <p>Not all firmware flashing will trip Knox. You can safely flash:</p>
      <ul>
        <li>Official firmware from Samsung (same model, same region)</li>
        <li>Official firmware with a newer bootloader version</li>
        <li>Firmware via Samsung Smart Switch</li>
      </ul>
      
      <h2>Checking Knox Status</h2>
      <p>To check if your Knox Warranty Bit has been tripped:</p>
      <ol>
        <li>Download the Phone Info SAM app from Google Play</li>
        <li>Go to the "Personal" tab</li>
        <li>Look for "Knox Warranty Void" - if it shows "0x0", Knox is intact; if "0x1", Knox has been tripped</li>
      </ol>
      
      <h2>Is It Worth Tripping Knox?</h2>
      <p>This depends on your priorities. If you rely on Samsung Pay, Secure Folder, or need your device for work in a BYOD environment, preserving Knox should be a priority. If these features aren't important to you, then the enhanced customization of custom ROMs might be worth the tradeoff.</p>
      
      <h2>Check Before You Flash</h2>
      <p>Our <a href="/firmware-checker">Firmware Compatibility Checker</a> can tell you whether a particular firmware installation is likely to trip Knox, helping you make informed decisions before flashing.</p>`,
      excerpt: "Learn about Samsung Knox security, how it protects your device, and why it matters when you're considering flashing new firmware.",
      featuredImage: "https://images.unsplash.com/photo-1633265486501-0cf524a07213?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&h=500",
      published: true
    }
  ];
  
  for (const post of sampleBlogPosts) {
    await db.insert(blogPosts).values(post).onConflictDoNothing();
  }

  // Seed site settings (including ads settings)
  console.log("Seeding site settings...");
  const sampleSettings: InsertSiteSetting[] = [
    {
      settingKey: "site_name",
      settingValue: "SamFirms",
      category: "general"
    },
    {
      settingKey: "site_description",
      settingValue: "AI-powered Samsung firmware compatibility checker and flashing guide",
      category: "seo"
    },
    {
      settingKey: "ads_enabled",
      settingValue: "true",
      category: "ads"
    },
    {
      settingKey: "ads_header",
      settingValue: "<div id='header-ad' class='ad-container'><!-- Header Ad Code --></div>",
      category: "ads"
    },
    {
      settingKey: "ads_sidebar",
      settingValue: "<div id='sidebar-ad' class='ad-container'><!-- Sidebar Ad Code --></div>",
      category: "ads"
    },
    {
      settingKey: "ads_footer",
      settingValue: "<div id='footer-ad' class='ad-container'><!-- Footer Ad Code --></div>",
      category: "ads"
    },
    {
      settingKey: "ads_inbetween_results",
      settingValue: "<div id='results-ad' class='ad-container'><!-- Results Ad Code --></div>",
      category: "ads"
    },
    {
      settingKey: "ads_responsive",
      settingValue: "<div id='responsive-ad' class='ad-container'><!-- Responsive Ad Code --></div>",
      category: "ads"
    },
    {
      settingKey: "analytics_enabled",
      settingValue: "true",
      category: "analytics"
    },
    {
      settingKey: "analytics_code",
      settingValue: "<!-- Analytics Code -->",
      category: "analytics"
    },
    {
      settingKey: "meta_keywords",
      settingValue: "Samsung firmware, firmware checker, CSC codes, flash Samsung, Knox security, phone firmware",
      category: "seo"
    },
    {
      settingKey: "meta_author",
      settingValue: "SamFirms Team",
      category: "seo"
    }
  ];
  
  for (const setting of sampleSettings) {
    await db.insert(siteSettings).values(setting).onConflictDoNothing();
  }

  console.log("✅ Database seeded successfully");
  process.exit(0);
}

main().catch((e) => {
  console.error("❌ Error seeding database:", e);
  process.exit(1);
});